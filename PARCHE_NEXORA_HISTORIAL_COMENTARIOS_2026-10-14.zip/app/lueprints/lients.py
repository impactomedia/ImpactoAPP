import sv
mport o
mport son
mport nicodedata
rom athlib mport ath
rom atetime mport ate,20datetime
rom ecimal mport ecimal,20InvalidOperation
0Afrom lask mport lueprint,20render_template,20request,20redirect,20url_for,20flash,20Response,20current_app,20send_from_directory,20abort
rom lask_login mport ogin_required,20current_user
rom qlalchemy mport r_
0Afrom pp.commercial_plans mport aintenance_label
rom pp.extensions mport b
rom pp.decorators mport ermission_required,20roles_required
rom pp.access_control mport commercial_client_allowed,20_project_allowed,20_task_allowed
rom pp.helpers mport udit,20next_code,20save_upload
rom pp.services mport ecalc_sale,20active_principal_contract
rom pp.models mport 
20 20 lient,0A 20 20Collaborator,0A 20 20ClientCollaborator,0A 20 20ClientContract,0A 20 20ProductService,0A 20 20Attachment,0A 20 20ClientComment,0A 20 20AdvisorProject,0A 20 20User,0A 20 20OwnershipHistory,0A 20 20Interaction,0A 20 20Quote,0A 20 20Sale,0A 20 20Payment,0A 20 20AccountReceivable,0A 20 20Project,0A 20 20Task,0A 20 20PrintOrder,0A 20 20Renewal,0A 20 20SupportTicket,0A 20 20TaskComment,0A 20 20ChangeRequest,0A 20 20TicketComment,0A 20 20PrintItem,0A 20 20DesignVersion,0A 20 20Shipment,0A 20 20PrintIncident,0A 20 20AuditLog,0A)
0Afrom pp.client_v2_models mport 
20 20 lientOperationalProfile,0A 20 20ClientPlatform,0A 20 20ClientContractDetail,0A 20 20ClientInstallment,0A 20 20ClientCollectionNote,0A 20 20ClientDocumentMeta,0A)
0Abp 3D lueprint("lients"2C _name__,20url_prefix=22/lients"
0ACLIENT_STATUSES 3D 7B"ctivo"2C 22inactivo"2C 22caducado"2C 22archivado"7D
ONTRACT_STATUSES 3D 7B"ctivo"2C 22inactivo"2C 22caducado"7D
LATFORM_STATUSES 3D 7B"ctivo"2C 22pendiente"2C 22inactivo"2C 22no_aplica"7D
LATFORM_DEFINITIONS 3D 7B
20 20 22google_business"3A 22Google usiness rofile 2F aps"2C
20 20 22youtube"3A 22YouTube"2C
20 20 22tiktok"3A 22TikTok"2C
20 20 22vimeo"3A 22Vimeo"2C
20 20 22pinterest"3A 22Pinterest"2C
20 20 22linkedin"3A 22LinkedIn"2C
20 20 22manta"3A 22Manta"2C
20 20 22houzz"3A 22Houzz"2C
20 20 22porch"3A 22Porch"2C
20 20 22buildzoom"3A 22BuildZoom"2C
20 20 22merchantcircle"3A 22MerchantCircle"2C
20 20 22mapquest"3A 22MapQuest"2C
20 20 22yelp"3A 22Yelp"2C
20 20 22yellow_pages"3A 22Yellow ages"2C
7D
0ADOCUMENT_CATEGORIES 3D 7B
20 20 22administrativo"3A 22Administrativo"2C
20 20 22contrato"3A 22Contrato 2F cuerdo"2C
20 20 22branding"3A 22Branding 2F ogotipo"2C
20 20 22website"3A 22Website 2F ominio"2C
20 20 22redes_sociales"3A 22Redes ociales"2C
20 20 22seo"3A 22SEO 2F oogle"2C
20 20 22imprenta"3A 22Imprenta"2C
20 20 22comprobante"3A 22Comprobante e ago"2C
20 20 22otros"3A 22Otros"2C
7D
OLLECTION_NOTE_TYPES 3D 7B"obranza"2C 22promesa"2C 22acuerdo"2C 22seguimiento"2C 22interno"7D
OLLECTION_NOTE_STATUSES 3D 7B"bierta"2C 22cumplida"2C 22incumplida"2C 22cancelada"7D
0A
ef normalize_text(value):0A 20 20value 3D tr(value r 22".strip().lower()
20 20 alue 3D 22"join(
20 20 20 20 har or har n nicodedata.normalize("FKD"2C alue)
20 20 20 20 f ot nicodedata.combining(char)
20 20 
20 20 eturn 22 22.join(value.split())
0A
ef normalize_key(value):0A 20 20value 3D normalize_text(value)
20 20 or har n "20"2C 22-"2C 22/22,20""2C 22#22,20""2C 22)":0A 20 20 20 20value 3D alue.replace(char,20""
20 20 hile 22__"20in alue:0A 20 20 20 20value 3D alue.replace("_"2C 22_"
20 20 eturn alue.strip(""
0A
ef normalized_row(row):0A 20 20return 7B_normalize_key(key):20(value r 22".strip() or ey,20value n ow.items() f ey s ot one}0A
0Adef pick(row,20*keys):0A 20 20for ey n eys:0A 20 20 20 20value 3D ow.get(_normalize_key(key),20"22)
20 20 20 20 f alue ot n None,20"22):0A 20 20 20 20 20 20return tr(value).strip()
20 20 eturn 22"0A
0Adef decimal_or_none(value):0A 20 20raw 3D tr(value r 22".strip().replace("24"2C 22".replace("2C"2C 22"
20 20 f ot aw:0A 20 20 20 20return one
20 20 ry:0A 20 20 20 20return ecimal(raw)
20 20 xcept InvalidOperation,20ValueError):0A 20 20 20 20return one
0A
ef date_or_none(value):0A 20 20raw 3D tr(value r 22".strip()
20 20 f ot aw:0A 20 20 20 20return one
20 20 ry:0A 20 20 20 20return ate.fromisoformat(raw)
20 20 xcept alueError:0A 20 20 20 20return one
0A
ef clean_url(value):0A 20 20raw 3D tr(value r 22".strip()
20 20 f ot aw:0A 20 20 20 20return one
20 20 f ot aw.lower().startswith(("ttp:2F/22,20"ttps:2F/22)):0A 20 20 20 20raw 3D "ttps:2F/7Braw}22
20 20 eturn aw[3A500]0A
0Adef visible_client_query(query=one):0A 20 20if uery s one:0A 20 20 20 20query 3D lient.query
20 20 ole 3D urrent_user.role.name f urrent_user.role lse 22"0A 20 20collaborator 3D urrent_user.collaborator
0A 20 20if ole 3D=20"dvisor"20and ollaborator:0A 20 20 20 20return uery.filter(Client.owner_id 3D=20collaborator.id)
0A 20 20if ole 3D=20"upervisor"20and ollaborator:0A 20 20 20 20allowed_ids 3D 5Bcollaborator.id]20+20[.id or  n ollaborator.subordinates]0A 20 20 20 20return uery.filter(Client.owner_id.in_(allowed_ids))
0A 20 20return uery
0A
ef active_collaborators():0A 20 20query 3D 
20 20 20 20 ollaborator.query
20 20 20 20 join(User,20Collaborator.user_id 3D=20User.id)
20 20 20 20 filter(Collaborator.status 3D=20"ctivo"
20 20 
20 20 ole 3D urrent_user.role.name f urrent_user.role lse 22"0A 20 20collaborator 3D urrent_user.collaborator
0A 20 20if ole 3D=20"dvisor"20and ollaborator:0A 20 20 20 20query 3D uery.filter(Collaborator.id 3D=20collaborator.id)
20 20 lif ole 3D=20"upervisor"20and ollaborator:0A 20 20 20 20allowed_ids 3D 5Bcollaborator.id]20+20[.id or  n ollaborator.subordinates]0A 20 20 20 20query 3D uery.filter(Collaborator.id.in_(allowed_ids))
0A 20 20return uery.order_by(User.name).all()
0A
ef owner_aliases(collaborators):0A 20 20aliases 3D 7B}0A 20 20for ollaborator n ollaborators:0A 20 20 20 20if ot ollaborator.user:0A 20 20 20 20 20 20continue
20 20 20 20 ull_name 3D normalize_text(collaborator.user.name)
20 20 20 20 f ull_name:0A 20 20 20 20 20 20aliases.setdefault(full_name,20collaborator.id)
20 20 20 20 20 20 liases.setdefault(full_name.split()[]2C ollaborator.id)
20 20 20 20 f ollaborator.code:0A 20 20 20 20 20 20aliases.setdefault(_normalize_text(collaborator.code),20collaborator.id)
20 20 eturn liases
0A
ef find_duplicate(business_name,20phone=one,20email=one,20exclude_id=one):0A 20 20conditions 3D 5B]0A 20 20if usiness_name:0A 20 20 20 20conditions.append(Client.business_name 3D=20business_name)
20 20 f hone:0A 20 20 20 20conditions.append(Client.phone 3D=20phone)
20 20 f mail:0A 20 20 20 20conditions.append(Client.email 3D=20email)
20 20 f ot onditions:0A 20 20 20 20return one
20 20 uery 3D lient.query.filter(or_(*conditions))
20 20 f xclude_id:0A 20 20 20 20query 3D uery.filter(Client.id =20exclude_id)
20 20 eturn uery.first()
0A
ef apply_client_form(client):0A 20 20text_fields 3D 5B
20 20 20 20 22business_name"2C
20 20 20 20 22contact_name"2C
20 20 20 20 22phone"2C
20 20 20 20 22other_phones"2C
20 20 20 20 22email"2C
20 20 20 20 22preferred_channel"2C
20 20 20 20 22industry"2C
20 20 20 20 22services_offered"2C
20 20 20 20 22website"2C
20 20 20 20 22facebook"2C
20 20 20 20 22instagram"2C
20 20 20 20 22other_social"2C
20 20 20 20 22address"2C
20 20 20 20 22city"2C
20 20 20 20 22state"2C
20 20 20 20 22country"2C
20 20 20 20 22timezone"2C
20 20 20 20 22source"2C
20 20 20 20 22priority"2C
20 20 20 20 22main_interest"2C
20 20 20 20 22notes"2C
20 20 5D
20 20 or ield n ext_fields:0A 20 20 20 20if ield n equest.form:0A 20 20 20 20 20 20value 3D equest.form.get(field)
20 20 20 20 20 20 f ield 3D=20"mail"3A
20 20 20 20 20 20 20 20 alue 3D value r 22".strip().lower()
20 20 20 20 20 20 etattr(client,20field,20value.strip() f sinstance(value,20str) lse alue)
0A 20 20client.country 3D 22USA"0A
20 20 23 ambiar l esponsable omercial s na cci�B3n eparada e ditar a icha.
20 20 23 olo uien enga rm.transfer uede scoger tro esponsable.
20 20 f urrent_user.has_permission("rm.transfer":0A 20 20 20 20client.owner_id 3D equest.form.get("wner_id"2C ype=nt) r one
20 20 lif urrent_user.collaborator nd ot lient.owner_id:0A 20 20 20 20client.owner_id 3D urrent_user.collaborator.id
0A 20 20client.client_status 3D equest.form.get("lient_status"2C lient.client_status r 22activo"
20 20 f lient.client_status ot n LIENT_STATUSES:0A 20 20 20 20client.client_status 3D 22activo"0A 20 20client.estimated_budget 3D decimal_or_none(request.form.get("stimated_budget")
20 20 lient.record_type 3D 22cliente"0A 20 20client.pipeline_stage 3D 22venta_cerrada"0A
0Adef apply_operational_profile_form(client,20profile=one):0A 20 20profile 3D rofile r lientOperationalProfile.query.filter_by(
20 20 20 20 lient_id=lient.id
20 20 .first()
20 20 f ot rofile:0A 20 20 20 20profile 3D lientOperationalProfile(client_id=lient.id)
20 20 20 20 b.session.add(profile)
0A 20 20text_fields 3D 5B
20 20 20 20 22attention_days"2C
20 20 20 20 22business_hours"2C
20 20 20 20 22experience_text"2C
20 20 20 20 22coverage_text"2C
20 20 20 20 22payment_methods"2C
20 20 20 20 22estimate_policy"2C
20 20 20 20 22languages"2C
20 20 20 20 22whatsapp_phone"2C
20 20 20 20 22postal_code"2C
20 20 20 20 22services_to_promote"2C
20 20 20 20 22logo_status"2C
20 20 20 20 22brand_colors"2C
20 20 20 20 22domain_name"2C
20 20 20 20 22domain_provider"2C
20 20 20 20 22hosting_provider"2C
20 20 20 20 22domain_notes"2C
20 20 20 20 22operational_notes"2C
20 20 5D
20 20 or ield n ext_fields:0A 20 20 20 20if ield n equest.form:0A 20 20 20 20 20 20value 3D request.form.get(field) r 22".strip()
20 20 20 20 20 20 etattr(profile,20field,20value r one)
0A 20 20for ield n 5B
20 20 20 20 22operational_email"2C
20 20 20 20 22corporate_email"2C
20 20 20 20 22hosting_account_email"2C
20 20 5D:0A 20 20 20 20if ield n equest.form:0A 20 20 20 20 20 20value 3D request.form.get(field) r 22".strip().lower()
20 20 20 20 20 20 etattr(profile,20field,20value r one)
0A 20 20for ield n 5B
20 20 20 20 22domain_activated_on"2C
20 20 20 20 22domain_renews_on"2C
20 20 20 20 22hosting_activated_on"2C
20 20 20 20 22hosting_renews_on"2C
20 20 5D:0A 20 20 20 20if ield n equest.form:0A 20 20 20 20 20 20setattr(profile,20field,20_date_or_none(request.form.get(field)))
0A 20 20return rofile
0A
0Adef timeline_datetime(value):0A 20 20if sinstance(value,20datetime):0A 20 20 20 20return alue
20 20 f sinstance(value,20date):0A 20 20 20 20return atetime.combine(value,20datetime.min.time())
20 20 eturn one
0A
ef timeline_event(events,20when,20category,20kind,20title,20body=one,20link=one,20actor=one):0A 20 20dt 3D timeline_datetime(when)
20 20 f ot t:0A 20 20 20 20return
20 20 vents.append({0A 20 20 20 20"t"3A t,0A 20 20 20 20"ategory"3A ategory,0A 20 20 20 20"ind"3A ind,0A 20 20 20 20"itle"3A itle,0A 20 20 20 20"ody"3A ody r 22"2C
20 20 20 20 22link"3A ink,0A 20 20 20 20"ctor"3A ctor,0A 20 20}
0A
ef json_dict(raw):0A 20 20if ot aw:0A 20 20 20 20return 7B}0A 20 20try:0A 20 20 20 20value 3D son.loads(raw)
20 20 20 20 eturn alue f sinstance(value,20dict) lse 7B}0A 20 20except TypeError,20ValueError,20json.JSONDecodeError):0A 20 20 20 20return 7B}0A
0Adef audit_change_text(log):0A 20 20before 3D json_dict(log.before_json)
20 20 fter 3D json_dict(log.after_json)
20 20 arts 3D 5B]0A
20 20 f 22status"20in efore r 22status"20in fter:0A 20 20 20 20previous 3D efore.get("tatus"
20 20 20 20 urrent 3D fter.get("tatus"
20 20 20 20 f revious =20current:0A 20 20 20 20 20 20if revious nd urrent:0A 20 20 20 20 20 20 20 20parts.append(
20 20 20 20 20 20 20 20 20 20 "stado:20{tr(previous).replace('_',20' ).title()}20�86�20"0A 20 20 20 20 20 20 20 20 20 20f"7Bstr(current).replace('_',20' ).title()}22
20 20 20 20 20 20 20 20 
20 20 20 20 20 20 lif urrent:0A 20 20 20 20 20 20 20 20parts.append(f"stado:20{tr(current).replace('_',20' ).title()}22)
0A 20 20if 22progress"20in efore r 22progress"20in fter:0A 20 20 20 20previous 3D efore.get("rogress"
20 20 20 20 urrent 3D fter.get("rogress"
20 20 20 20 f revious =20current nd urrent s ot one:0A 20 20 20 20 20 20parts.append(f"rogreso:20{urrent}25"
0A 20 20if 22decision"20in fter:0A 20 20 20 20parts.append(f"ecisi�B3n:20{tr(after[decision'].replace('_',20' ).title()}22)
20 20 f 22tracking"20in fter nd fter.get("racking":0A 20 20 20 20parts.append(f"racking:20{fter[tracking']7D"
20 20 f 22incident"20in fter nd fter.get("ncident":0A 20 20 20 20parts.append(f"ncidencia:20{tr(after[incident'].replace('_',20' ).title()}22)
20 20 f 22resolution"20in fter nd fter.get("esolution":0A 20 20 20 20parts.append(f"esoluci�B3n:20{fter[resolution']7D"
0A 20 20if ot arts nd og.reason:0A 20 20 20 20parts.append(log.reason)
0A 20 20return 22 C2�20"join(parts) r 22Registro ctualizado."0A
0Adef build_client_timeline(
20 20 lient,0A 20 20*,0A 20 20attachments,0A 20 20visible_projects,0A 20 20visible_tasks,0A 20 20can_financial,0A):0A 20 20"22"onstruye n imeline C3�ico eyendo os �B3dulos eales,20sin uplicar atos."22"0A 20 20events 3D 5B]0A
20 20 an_crm 3D urrent_user.has_permission("rm.view"
20 20 an_sales 3D urrent_user.has_permission("ales.view"
20 20 an_projects 3D urrent_user.has_permission("rojects.view"
20 20 an_tasks 3D urrent_user.has_permission("asks.view"
20 20 an_support 3D urrent_user.has_permission("upport.view"
20 20 an_printing 3D urrent_user.has_permission("rinting.view"
0A 20 20#20CRM 2F eguimiento reservado.
20 20 f an_crm:0A 20 20 20 20for nteraction n lient.interactions:0A 20 20 20 20 20 20_timeline_event(
20 20 20 20 20 20 20 20 vents,0A 20 20 20 20 20 20 20 20interaction.occurred_at r nteraction.created_at,0A 20 20 20 20 20 20 20 20"rm"2C
20 20 20 20 20 20 20 20 22Interacci�B3n"2C
20 20 20 20 20 20 20 20 nteraction.subject r nteraction.interaction_type.replace(""2C 22 22).title(),0A 20 20 20 20 20 20 20 20interaction.notes r nteraction.result,0A 20 20 20 20 20 20 20 20actor=nteraction.user.name f nteraction.user lse one,0A 20 20 20 20 20 20)
0A 20 20 20 20for uote n lient.quotes:0A 20 20 20 20 20 20body 3D "stado:20{uote.status.replace('_',20' ).title()}22
20 20 20 20 20 20 f an_financial:0A 20 20 20 20 20 20 20 20body 2B=20f"20�B7 otal SD 7Bquote.total}22
20 20 20 20 20 20 timeline_event(
20 20 20 20 20 20 20 20 vents,0A 20 20 20 20 20 20 20 20quote.created_at,0A 20 20 20 20 20 20 20 20"omercial"2C
20 20 20 20 20 20 20 20 22Cotizaci�B3n"2C
20 20 20 20 20 20 20 20 uote.quote_no,0A 20 20 20 20 20 20 20 20body,0A 20 20 20 20 20 20)
0A 20 20#20Servicio rincipal 2F ontratos:20visible omo ontexto perativo,20sin xponer aldo.
20 20 or ontract n lient.contracts:0A 20 20 20 20product_name 3D ontract.product.name f ontract.product lse 22Servicio"0A 20 20 20 20kind 3D 22Servicio rincipal"20if ontract.principal lse 22Servicio"0A 20 20 20 20body 3D "stado:20{ontract.status.replace('_',20' ).title()}22
20 20 20 20 f ontract.starts_on:0A 20 20 20 20 20 20body 2B=20f"20�B7 nicio:20{ontract.starts_on}22
20 20 20 20 f ontract.ends_on:0A 20 20 20 20 20 20body 2B=20f"20�B7 in:20{ontract.ends_on}22
20 20 20 20 timeline_event(
20 20 20 20 20 20 vents,0A 20 20 20 20 20 20contract.created_at,0A 20 20 20 20 20 20"omercial"2C
20 20 20 20 20 20 ind,0A 20 20 20 20 20 20product_name,0A 20 20 20 20 20 20body,0A 20 20 20 20)
0A 20 20#20Ventas,20upgrades,20compras  agos olo on ermiso omercial/inanciero.
20 20 f an_financial:0A 20 20 20 20for ale n lient.sales:0A 20 20 20 20 20 20operation_type 3D 
20 20 20 20 20 20 20 20 ale.operation_meta.operation_type
20 20 20 20 20 20 20 20 f ale.operation_meta
20 20 20 20 20 20 20 20 lse 22additional_purchase"0A 20 20 20 20 20 20)
20 20 20 20 20 20 ale_label 3D 7B
20 20 20 20 20 20 20 20 22principal_service"3A 22Servicio rincipal"2C
20 20 20 20 20 20 20 20 22principal_upgrade"3A 22Upgrade"2C
20 20 20 20 20 20 20 20 22additional_purchase"3A 22Compra dicional"2C
20 20 20 20 20 20 7D.get(operation_type,20"enta"
20 20 20 20 20 20 timeline_event(
20 20 20 20 20 20 20 20 vents,0A 20 20 20 20 20 20 20 20sale.created_at,0A 20 20 20 20 20 20 20 20"omercial"2C
20 20 20 20 20 20 20 20 ale_label,0A 20 20 20 20 20 20 20 20sale.sale_no,0A 20 20 20 20 20 20 20 20f"otal SD 7Bsale.total}20�B7 stado:20{ale.status.replace('_',20' ).title()}22,0A 20 20 20 20 20 20 20 20link=rl_for("ales.detail"2C ale_id=ale.id),0A 20 20 20 20 20 20)
0A 20 20 20 20for ayment n lient.payments:0A 20 20 20 20 20 20_timeline_event(
20 20 20 20 20 20 20 20 vents,0A 20 20 20 20 20 20 20 20payment.created_at,0A 20 20 20 20 20 20 20 20"inanzas"2C
20 20 20 20 20 20 20 20 22Pago"2C
20 20 20 20 20 20 20 20 "SD 7Bpayment.amount}22,0A 20 20 20 20 20 20 20 20(
20 20 20 20 20 20 20 20 20 20 "7Bpayment.method r M�A9todo o ndicado'}22
20 20 20 20 20 20 20 20 20 20 2B f"20�B7 ef. 7Bpayment.reference}22 f ayment.reference lse 22"
20 20 20 20 20 20 20 20 20 20 2B "20�B7 7Bpayment.status.replace('_',20' ).title()}22
20 20 20 20 20 20 20 20 ,0A 20 20 20 20 20 20 20 20link=rl_for("ales.detail"2C ale_id=ayment.sale_id),0A 20 20 20 20 20 20)
0A 20 20 20 20for ote n lient.collection_notes:0A 20 20 20 20 20 20detail 3D ote.body
20 20 20 20 20 20 f ote.promise_date:0A 20 20 20 20 20 20 20 20detail 3D "7Bdetail}20�B7 ompromiso 7Bnote.promise_date}22
20 20 20 20 20 20 timeline_event(
20 20 20 20 20 20 20 20 vents,0A 20 20 20 20 20 20 20 20note.created_at,0A 20 20 20 20 20 20 20 20"inanzas"2C
20 20 20 20 20 20 20 20 22Cobranza"2C
20 20 20 20 20 20 20 20 ote.note_type.replace(""2C 22 22).title(),0A 20 20 20 20 20 20 20 20detail,0A 20 20 20 20 20 20)
0A 20 20#20Comentarios nternos orman arte el xpediente,20no e uplican anualmente.
20 20 omments 3D 
20 20 20 20 lientComment.query
20 20 20 20 filter_by(client_id=lient.id)
20 20 20 20 order_by(ClientComment.created_at.desc())
20 20 20 20 all()
20 20 
20 20 or omment n omments:0A 20 20 20 20detail 3D omment.process_detail r omment.department_snapshot r 22"0A 20 20 20 20_timeline_event(
20 20 20 20 20 20 vents,0A 20 20 20 20 20 20comment.created_at,0A 20 20 20 20 20 20"nterno"2C
20 20 20 20 20 20 22Comentario nterno"2C
20 20 20 20 20 20 "7Bcomment.user.name}20�B7 7Bcomment.process_type}22,0A 20 20 20 20 20 20f"7Bdetail}20�80�20{omment.body}22 f etail lse omment.body,0A 20 20 20 20 20 20actor=omment.user.name f omment.user lse one,0A 20 20 20 20)
0A 20 20#20Desarrollo 2F royectos 2F areas.
20 20 roject_ids 3D 7Brow.id or ow n isible_projects}0A 20 20task_ids 3D 7Brow.id or ow n isible_tasks}0A
20 20 f an_projects:0A 20 20 20 20for roject n isible_projects:0A 20 20 20 20 20 20body 3D 
20 20 20 20 20 20 20 20 "stado:20{roject.status.replace('_',20' ).title()}20�B7 22
20 20 20 20 20 20 20 20 "rogreso:20{roject.progress r }25"0A 20 20 20 20 20 20)
20 20 20 20 20 20 timeline_event(
20 20 20 20 20 20 20 20 vents,0A 20 20 20 20 20 20 20 20project.created_at,0A 20 20 20 20 20 20 20 20"esarrollo"2C
20 20 20 20 20 20 20 20 22Proyecto"2C
20 20 20 20 20 20 20 20 roject.name,0A 20 20 20 20 20 20 20 20body,0A 20 20 20 20 20 20 20 20link=rl_for("perations.project_detail"2C roject_id=roject.id),0A 20 20 20 20 20 20)
20 20 20 20 f roject_ids:0A 20 20 20 20 20 20for hange n 
20 20 20 20 20 20 20 20 hangeRequest.query
20 20 20 20 20 20 20 20 filter(ChangeRequest.project_id.in_(project_ids))
20 20 20 20 20 20 20 20 order_by(ChangeRequest.created_at.desc())
20 20 20 20 20 20 20 20 all()
20 20 20 20 20 20 :0A 20 20 20 20 20 20 20 20_timeline_event(
20 20 20 20 20 20 20 20 20 20 vents,0A 20 20 20 20 20 20 20 20 20 20change.created_at,0A 20 20 20 20 20 20 20 20 20 20"esarrollo"2C
20 20 20 20 20 20 20 20 20 20 22Solicitud e ambio"2C
20 20 20 20 20 20 20 20 20 20 hange.title,0A 20 20 20 20 20 20 20 20 20 20(
20 20 20 20 20 20 20 20 20 20 20 20 "7Bchange.scope_class.replace('_',20' ).title()}20�B7 22
20 20 20 20 20 20 20 20 20 20 20 20 "7Bchange.status.replace('_',20' ).title()}22
20 20 20 20 20 20 20 20 20 20 20 20 2B f"20�B7 7Bchange.description}22 f hange.description lse 22"
20 20 20 20 20 20 20 20 20 20 ,0A 20 20 20 20 20 20 20 20 20 20link=rl_for("perations.project_detail"2C roject_id=hange.project_id),0A 20 20 20 20 20 20 20 20)
0A 20 20if an_tasks:0A 20 20 20 20for ask n isible_tasks:0A 20 20 20 20 20 20_timeline_event(
20 20 20 20 20 20 20 20 vents,0A 20 20 20 20 20 20 20 20task.created_at,0A 20 20 20 20 20 20 20 20"esarrollo"2C
20 20 20 20 20 20 20 20 22Tarea"2C
20 20 20 20 20 20 20 20 ask.title,0A 20 20 20 20 20 20 20 20f"stado:20{ask.status.replace('_',20' ).title()}20�B7 rioridad:20{ask.priority.title()}22,0A 20 20 20 20 20 20 20 20link=rl_for("perations.task_detail"2C ask_id=ask.id),0A 20 20 20 20 20 20)
20 20 20 20 f ask_ids:0A 20 20 20 20 20 20for omment n 
20 20 20 20 20 20 20 20 askComment.query
20 20 20 20 20 20 20 20 filter(TaskComment.task_id.in_(task_ids))
20 20 20 20 20 20 20 20 order_by(TaskComment.created_at.desc())
20 20 20 20 20 20 20 20 all()
20 20 20 20 20 20 :0A 20 20 20 20 20 20 20 20_timeline_event(
20 20 20 20 20 20 20 20 20 20 vents,0A 20 20 20 20 20 20 20 20 20 20comment.created_at,0A 20 20 20 20 20 20 20 20 20 20"esarrollo"2C
20 20 20 20 20 20 20 20 20 20 22Comentario e area"2C
20 20 20 20 20 20 20 20 20 20 omment.task.title f omment.task lse 22Tarea"2C
20 20 20 20 20 20 20 20 20 20 omment.body,0A 20 20 20 20 20 20 20 20 20 20link=rl_for("perations.task_detail"2C ask_id=omment.task_id),0A 20 20 20 20 20 20 20 20 20 20actor=omment.user.name f omment.user lse one,0A 20 20 20 20 20 20 20 20)
0A 20 20#20Soporte.
20 20 ickets 3D 5B]0A 20 20if an_support:0A 20 20 20 20tickets 3D ist(client.tickets)
20 20 20 20 or icket n ickets:0A 20 20 20 20 20 20_timeline_event(
20 20 20 20 20 20 20 20 vents,0A 20 20 20 20 20 20 20 20ticket.created_at,0A 20 20 20 20 20 20 20 20"oporte"2C
20 20 20 20 20 20 20 20 22Ticket"2C
20 20 20 20 20 20 20 20 "7Bticket.ticket_no}20�B7 7Bticket.subject}22,0A 20 20 20 20 20 20 20 20(
20 20 20 20 20 20 20 20 20 20 "stado:20{icket.status.replace('_',20' ).title()}20�B7 22
20 20 20 20 20 20 20 20 20 20 "rioridad:20{icket.priority.title()}22
20 20 20 20 20 20 20 20 ,0A 20 20 20 20 20 20 20 20link=rl_for("upport.detail"2C icket_id=icket.id),0A 20 20 20 20 20 20)
20 20 20 20 icket_ids 3D 7Brow.id or ow n ickets}0A 20 20 20 20if icket_ids:0A 20 20 20 20 20 20for omment n 
20 20 20 20 20 20 20 20 icketComment.query
20 20 20 20 20 20 20 20 filter(TicketComment.ticket_id.in_(ticket_ids))
20 20 20 20 20 20 20 20 order_by(TicketComment.created_at.desc())
20 20 20 20 20 20 20 20 all()
20 20 20 20 20 20 :0A 20 20 20 20 20 20 20 20_timeline_event(
20 20 20 20 20 20 20 20 20 20 vents,0A 20 20 20 20 20 20 20 20 20 20comment.created_at,0A 20 20 20 20 20 20 20 20 20 20"oporte"2C
20 20 20 20 20 20 20 20 20 20 22Comentario e oporte"2C
20 20 20 20 20 20 20 20 20 20 omment.ticket.subject f omment.ticket lse 22Ticket"2C
20 20 20 20 20 20 20 20 20 20 omment.body,0A 20 20 20 20 20 20 20 20 20 20link=rl_for("upport.detail"2C icket_id=omment.ticket_id),0A 20 20 20 20 20 20 20 20 20 20actor=omment.user.name f omment.user lse one,0A 20 20 20 20 20 20 20 20)
0A 20 20#20Imprenta 2F videncias 2F nv�ADos.
20 20 rders 3D 5B]0A 20 20print_items 3D 5B]0A 20 20shipments 3D 5B]0A 20 20incidents 3D 5B]0A 20 20if an_printing:0A 20 20 20 20orders 3D ist(client.print_orders)
20 20 20 20 rder_ids 3D 7Brow.id or ow n rders}0A
20 20 20 20 or rder n rders:0A 20 20 20 20 20 20_timeline_event(
20 20 20 20 20 20 20 20 vents,0A 20 20 20 20 20 20 20 20order.created_at,0A 20 20 20 20 20 20 20 20"mprenta"2C
20 20 20 20 20 20 20 20 22Orden e mprenta"2C
20 20 20 20 20 20 20 20 rder.order_no,0A 20 20 20 20 20 20 20 20f"stado:20{rder.status.replace('_',20' ).title()}22,0A 20 20 20 20 20 20 20 20link=rl_for("rinting.detail"2C rder_id=rder.id),0A 20 20 20 20 20 20)
0A 20 20 20 20if rder_ids:0A 20 20 20 20 20 20print_items 3D 
20 20 20 20 20 20 20 20 rintItem.query
20 20 20 20 20 20 20 20 filter(PrintItem.order_id.in_(order_ids))
20 20 20 20 20 20 20 20 all()
20 20 20 20 20 20 
20 20 20 20 20 20 tem_ids 3D 7Brow.id or ow n rint_items}0A
20 20 20 20 20 20 f tem_ids:0A 20 20 20 20 20 20 20 20for ersion n 
20 20 20 20 20 20 20 20 20 20 esignVersion.query
20 20 20 20 20 20 20 20 20 20 filter(DesignVersion.print_item_id.in_(item_ids))
20 20 20 20 20 20 20 20 20 20 order_by(DesignVersion.created_at.desc())
20 20 20 20 20 20 20 20 20 20 all()
20 20 20 20 20 20 20 20 :0A 20 20 20 20 20 20 20 20 20 20_timeline_event(
20 20 20 20 20 20 20 20 20 20 20 20 vents,0A 20 20 20 20 20 20 20 20 20 20 20 20version.created_at,0A 20 20 20 20 20 20 20 20 20 20 20 20"mprenta"2C
20 20 20 20 20 20 20 20 20 20 20 20 22Dise�B1o argado"2C
20 20 20 20 20 20 20 20 20 20 20 20 "7Bversion.print_item.name}20�B7 {ersion.version}22,0A 20 20 20 20 20 20 20 20 20 20 20 20(
20 20 20 20 20 20 20 20 20 20 20 20 20 20 "stado:20{ersion.status.replace('_',20' ).title()}22
20 20 20 20 20 20 20 20 20 20 20 20 20 20 2B f"20�B7 7Bversion.comment}22 f ersion.comment lse 22"
20 20 20 20 20 20 20 20 20 20 20 20 ,0A 20 20 20 20 20 20 20 20 20 20 20 20link=rl_for("rinting.detail"2C rder_id=ersion.print_item.order_id),0A 20 20 20 20 20 20 20 20 20 20)
0A 20 20 20 20 20 20shipments 3D 
20 20 20 20 20 20 20 20 hipment.query
20 20 20 20 20 20 20 20 filter(Shipment.order_id.in_(order_ids))
20 20 20 20 20 20 20 20 all()
20 20 20 20 20 20 
20 20 20 20 20 20 or hipment n hipments:0A 20 20 20 20 20 20 20 20order 3D hipment.order
20 20 20 20 20 20 20 20 itle 3D rder.order_no f rder lse 22Env�ADo"0A 20 20 20 20 20 20 20 20if hipment.shipped_at:0A 20 20 20 20 20 20 20 20 20 20_timeline_event(
20 20 20 20 20 20 20 20 20 20 20 20 vents,0A 20 20 20 20 20 20 20 20 20 20 20 20shipment.shipped_at,0A 20 20 20 20 20 20 20 20 20 20 20 20"mprenta"2C
20 20 20 20 20 20 20 20 20 20 20 20 22Env�ADo"2C
20 20 20 20 20 20 20 20 20 20 20 20 itle,0A 20 20 20 20 20 20 20 20 20 20 20 20(
20 20 20 20 20 20 20 20 20 20 20 20 20 20 "7Bshipment.carrier r Entrega ocal'}22
20 20 20 20 20 20 20 20 20 20 20 20 20 20 2B f"20�B7 racking 7Bshipment.tracking_number}22 f hipment.tracking_number lse 22"
20 20 20 20 20 20 20 20 20 20 20 20 20 20 2B "20�B7 7Bshipment.status.replace('_',20' ).title()}22
20 20 20 20 20 20 20 20 20 20 20 20 ,0A 20 20 20 20 20 20 20 20 20 20 20 20link=rl_for("rinting.detail"2C rder_id=hipment.order_id),0A 20 20 20 20 20 20 20 20 20 20)
20 20 20 20 20 20 20 20 f hipment.received_at:0A 20 20 20 20 20 20 20 20 20 20_timeline_event(
20 20 20 20 20 20 20 20 20 20 20 20 vents,0A 20 20 20 20 20 20 20 20 20 20 20 20shipment.received_at,0A 20 20 20 20 20 20 20 20 20 20 20 20"mprenta"2C
20 20 20 20 20 20 20 20 20 20 20 20 22Recepci�B3n"2C
20 20 20 20 20 20 20 20 20 20 20 20 itle,0A 20 20 20 20 20 20 20 20 20 20 20 20"nv�ADo arcado omo ecibido."2C
20 20 20 20 20 20 20 20 20 20 20 20 ink=rl_for("rinting.detail"2C rder_id=hipment.order_id),0A 20 20 20 20 20 20 20 20 20 20)
0A 20 20 20 20 20 20incidents 3D 
20 20 20 20 20 20 20 20 rintIncident.query
20 20 20 20 20 20 20 20 filter(PrintIncident.order_id.in_(order_ids))
20 20 20 20 20 20 20 20 all()
20 20 20 20 20 20 
20 20 20 20 20 20 or ncident n ncidents:0A 20 20 20 20 20 20 20 20_timeline_event(
20 20 20 20 20 20 20 20 20 20 vents,0A 20 20 20 20 20 20 20 20 20 20incident.created_at,0A 20 20 20 20 20 20 20 20 20 20"mprenta"2C
20 20 20 20 20 20 20 20 20 20 22Incidencia e mprenta"2C
20 20 20 20 20 20 20 20 20 20 ncident.incident_type.replace(""2C 22 22).title(),0A 20 20 20 20 20 20 20 20 20 20incident.description,0A 20 20 20 20 20 20 20 20 20 20link=rl_for("rinting.detail"2C rder_id=ncident.order_id),0A 20 20 20 20 20 20 20 20)
20 20 20 20 20 20 20 20 f ncident.status 3D=20"esuelta"20and ncident.updated_at:0A 20 20 20 20 20 20 20 20 20 20_timeline_event(
20 20 20 20 20 20 20 20 20 20 20 20 vents,0A 20 20 20 20 20 20 20 20 20 20 20 20incident.updated_at,0A 20 20 20 20 20 20 20 20 20 20 20 20"mprenta"2C
20 20 20 20 20 20 20 20 20 20 20 20 22Incidencia esuelta"2C
20 20 20 20 20 20 20 20 20 20 20 20 ncident.incident_type.replace(""2C 22 22).title(),0A 20 20 20 20 20 20 20 20 20 20 20 20incident.resolution r 22Incidencia esuelta."2C
20 20 20 20 20 20 20 20 20 20 20 20 ink=rl_for("rinting.detail"2C rder_id=ncident.order_id),0A 20 20 20 20 20 20 20 20 20 20)
0A 20 20#20Archivos el xpediente.
20 20 or ttachment n ttachments:0A 20 20 20 20_timeline_event(
20 20 20 20 20 20 vents,0A 20 20 20 20 20 20attachment.created_at,0A 20 20 20 20 20 20"rchivos"2C
20 20 20 20 20 20 22Archivo djunto"2C
20 20 20 20 20 20 ttachment.file_name,0A 20 20 20 20 20 20"ocumento gregado l xpediente el liente."2C
20 20 20 20 20 20 ink=rl_for(
20 20 20 20 20 20 20 20 22clients.download_attachment"2C
20 20 20 20 20 20 20 20 lient_id=lient.id,0A 20 20 20 20 20 20 20 20attachment_id=ttachment.id,0A 20 20 20 20 20 20),0A 20 20 20 20)
0A 20 20#20Renovaciones.
20 20 f an_sales:0A 20 20 20 20for enewal n lient.renewals:0A 20 20 20 20 20 20_timeline_event(
20 20 20 20 20 20 20 20 vents,0A 20 20 20 20 20 20 20 20renewal.created_at,0A 20 20 20 20 20 20 20 20"enovaciones"2C
20 20 20 20 20 20 20 20 22Renovaci�B3n rogramada"2C
20 20 20 20 20 20 20 20 enewal.renewal_type,0A 20 20 20 20 20 20 20 20(
20 20 20 20 20 20 20 20 20 20 "ence:20{enewal.due_date}20�B7 22
20 20 20 20 20 20 20 20 20 20 "stado:20{enewal.status.replace('_',20' ).title()}22
20 20 20 20 20 20 20 20 ,0A 20 20 20 20 20 20)
20 20 20 20 20 20 f enewal.last_contact_at:0A 20 20 20 20 20 20 20 20_timeline_event(
20 20 20 20 20 20 20 20 20 20 vents,0A 20 20 20 20 20 20 20 20 20 20renewal.last_contact_at,0A 20 20 20 20 20 20 20 20 20 20"enovaciones"2C
20 20 20 20 20 20 20 20 20 20 22Contacto e enovaci�B3n"2C
20 20 20 20 20 20 20 20 20 20 enewal.renewal_type,0A 20 20 20 20 20 20 20 20 20 20renewal.notes r 22Seguimiento e enovaci�B3n."2C
20 20 20 20 20 20 20 20 
0A 20 20#20Cambios e esponsable omercial.
20 20 or ow n lient.ownership_history:0A 20 20 20 20previous 3D 
20 20 20 20 20 20 b.session.get(Collaborator,20row.previous_owner_id)
20 20 20 20 20 20 f ow.previous_owner_id
20 20 20 20 20 20 lse one
20 20 20 20 
20 20 20 20 ew_owner 3D 
20 20 20 20 20 20 b.session.get(Collaborator,20row.new_owner_id)
20 20 20 20 20 20 f ow.new_owner_id
20 20 20 20 20 20 lse one
20 20 20 20 
20 20 20 20 revious_name 3D revious.user.name f revious nd revious.user lse 22Sin signar"0A 20 20 20 20new_name 3D ew_owner.user.name f ew_owner nd ew_owner.user lse 22Sin signar"0A 20 20 20 20_timeline_event(
20 20 20 20 20 20 vents,0A 20 20 20 20 20 20row.changed_at,0A 20 20 20 20 20 20"nterno"2C
20 20 20 20 20 20 22Cambio e esponsable"2C
20 20 20 20 20 20 "7Bprevious_name}20�86�20{ew_name}22,0A 20 20 20 20 20 20row.reason r 22Transferencia e artera."2C
20 20 20 20 
0A 20 20#20Cambios e stado ist�B3ricos omados e uditLog.
20 20 udit_scopes 3D 7B
20 20 20 20 22Project"3A roject_ids f an_projects lse et(),0A 20 20 20 20"ask"3A ask_ids f an_tasks lse et(),0A 20 20 20 20"upportTicket"3A 7Brow.id or ow n ickets}2C
20 20 20 20 22PrintOrder"3A 7Brow.id or ow n rders}2C
20 20 20 20 22PrintItem"3A 7Brow.id or ow n rint_items}2C
20 20 20 20 22Shipment"3A 7Brow.id or ow n hipments}2C
20 20 20 20 22PrintIncident"3A 7Brow.id or ow n ncidents}2C
20 20 7D
20 20 udit_kind 3D 7B
20 20 20 20 22Project"3A "esarrollo"2C 22Cambio e royecto",0A 20 20 20 20"ask"3A "esarrollo"2C 22Cambio e area",0A 20 20 20 20"upportTicket"3A "oporte"2C 22Cambio e icket",0A 20 20 20 20"rintOrder"3A "mprenta"2C 22Cambio e mprenta",0A 20 20 20 20"rintItem"3A "mprenta"2C 22Cambio e ise�B1o",0A 20 20 20 20"hipment"3A "mprenta"2C 22Cambio e nv�ADo",0A 20 20 20 20"rintIncident"3A "mprenta"2C 22Cambio e ncidencia",0A 20 20}0A 20 20skipped_actions 3D 7B
20 20 20 20 22crear_proyecto"2C
20 20 20 20 22crear_tarea"2C
20 20 20 20 22crear_ticket"2C
20 20 20 20 22crear_orden_imprenta"2C
20 20 20 20 22comentario_tarea"2C
20 20 20 20 22comentario_ticket"2C
20 20 20 20 22cargar_diseno"2C
20 20 20 20 22producto_enviado"2C
20 20 20 20 22producto_recibido"2C
20 20 20 20 22incidencia_imprenta"2C
20 20 20 20 22resolver_incidencia_imprenta"2C
20 20 7D
0A 20 20for ntity,20ids n udit_scopes.items():0A 20 20 20 20if ot ds:0A 20 20 20 20 20 20continue
20 20 20 20 ogs 3D 
20 20 20 20 20 20 uditLog.query
20 20 20 20 20 20 filter(
20 20 20 20 20 20 20 20 uditLog.entity 3D=20entity,0A 20 20 20 20 20 20 20 20AuditLog.entity_id.in_([tr(value) or alue n ds],0A 20 20 20 20 20 20)
20 20 20 20 20 20 order_by(AuditLog.created_at.desc())
20 20 20 20 20 20 all()
20 20 20 20 
20 20 20 20 ategory,20kind 3D udit_kind[ntity]0A 20 20 20 20for og n ogs:0A 20 20 20 20 20 20if og.action n kipped_actions:0A 20 20 20 20 20 20 20 20continue
20 20 20 20 20 20 timeline_event(
20 20 20 20 20 20 20 20 vents,0A 20 20 20 20 20 20 20 20log.created_at,0A 20 20 20 20 20 20 20 20category,0A 20 20 20 20 20 20 20 20kind,0A 20 20 20 20 20 20 20 20log.action.replace(""2C 22 22).title(),0A 20 20 20 20 20 20 20 20_audit_change_text(log),0A 20 20 20 20 20 20 20 20actor=og.user.name f og.user lse one,0A 20 20 20 20 20 20)
0A 20 20#20Ediciones mportantes e a icha,20sin xponer os alores odificados.
20 20 or og n 
20 20 20 20 uditLog.query
20 20 20 20 filter(
20 20 20 20 20 20 uditLog.entity 3D=20"lient"2C
20 20 20 20 20 20 uditLog.entity_id 3D=20str(client.id),0A 20 20 20 20 20 20AuditLog.action.in_([0A 20 20 20 20 20 20 20 20"ditar_cliente"2C
20 20 20 20 20 20 20 20 22actualizar_perfil_operativo"2C
20 20 20 20 20 20 20 20 22actualizar_plataforma"2C
20 20 20 20 20 20 5D),0A 20 20 20 20)
20 20 20 20 order_by(AuditLog.created_at.desc())
20 20 20 20 all()
20 20 :0A 20 20 20 20_timeline_event(
20 20 20 20 20 20 vents,0A 20 20 20 20 20 20log.created_at,0A 20 20 20 20 20 20"nterno"2C
20 20 20 20 20 20 22Ficha ctualizada"2C
20 20 20 20 20 20 og.action.replace(""2C 22 22).title(),0A 20 20 20 20 20 20"nformaci�B3n el xpediente ctualizada."2C
20 20 20 20 20 20 ctor=og.user.name f og.user lse one,0A 20 20 20 20)
0A 20 20#20Cambios e tapa el eguimiento omercial,20preservados n uditLog.
20 20 f an_crm:0A 20 20 20 20stage_logs 3D 
20 20 20 20 20 20 uditLog.query
20 20 20 20 20 20 filter(
20 20 20 20 20 20 20 20 uditLog.entity 3D=20"lient"2C
20 20 20 20 20 20 20 20 uditLog.entity_id 3D=20str(client.id),0A 20 20 20 20 20 20 20 20AuditLog.action 3D=20"ambiar_etapa"2C
20 20 20 20 20 20 
20 20 20 20 20 20 order_by(AuditLog.created_at.desc())
20 20 20 20 20 20 all()
20 20 20 20 
20 20 20 20 or og n tage_logs:0A 20 20 20 20 20 20previous 3D json_dict(log.before_json).get("tage"
20 20 20 20 20 20 urrent 3D json_dict(log.after_json).get("tage"
20 20 20 20 20 20 escription 3D 
20 20 20 20 20 20 20 20 "7Bstr(previous r Sin tapa').replace('_',20' ).title()}20�86�20"0A 20 20 20 20 20 20 20 20f"7Bstr(current r Sin tapa').replace('_',20' ).title()}22
20 20 20 20 20 20 
20 20 20 20 20 20 timeline_event(
20 20 20 20 20 20 20 20 vents,20log.created_at,20"rm"2C 22Cambio e tapa"2C
20 20 20 20 20 20 20 20 22Etapa omercial"2C escription,0A 20 20 20 20 20 20 20 20actor=og.user.name f og.user lse one,0A 20 20 20 20 20 20)
0A 20 20events.sort(key=ambda tem:20item[22dt"5D,20reverse=rue)
20 20 eturn vents
0Adef client_has_history(client_id):0A 20 20checks 3D 5B
20 20 20 20 "nteracciones"2C nteraction.query.filter_by(client_id=lient_id).first()),0A 20 20 20 20("omentarios"2C lientComment.query.filter_by(client_id=lient_id).first()),0A 20 20 20 20("signaciones"2C lientCollaborator.query.filter_by(client_id=lient_id).first()),0A 20 20 20 20("ontratos"2C lientContract.query.filter_by(client_id=lient_id).first()),0A 20 20 20 20("otizaciones"2C uote.query.filter_by(client_id=lient_id).first()),0A 20 20 20 20("entas"2C ale.query.filter_by(client_id=lient_id).first()),0A 20 20 20 20("agos"2C ayment.query.filter_by(client_id=lient_id).first()),0A 20 20 20 20("uentas or obrar"2C ccountReceivable.query.filter_by(client_id=lient_id).first()),0A 20 20 20 20("royectos"2C roject.query.filter_by(client_id=lient_id).first()),0A 20 20 20 20("areas"2C ask.query.filter_by(client_id=lient_id).first()),0A 20 20 20 20("C3�denes e mprenta"2C rintOrder.query.filter_by(client_id=lient_id).first()),0A 20 20 20 20("enovaciones"2C enewal.query.filter_by(client_id=lient_id).first()),0A 20 20 20 20("ickets"2C upportTicket.query.filter_by(client_id=lient_id).first()),0A 20 20 20 20("rchivos"2C ttachment.query.filter_by(entity_type=22Client"2C ntity_id=lient_id).first()),0A 20 20 20 20("istorial e esponsable"2C wnershipHistory.query.filter_by(client_id=lient_id).first()),0A 20 20 20 20("erfil perativo"2C lientOperationalProfile.query.filter_by(client_id=lient_id).first()),0A 20 20 20 20("lataformas"2C lientPlatform.query.filter_by(client_id=lient_id).first()),0A 20 20]0A 20 20return 5Blabel or abel,20row n hecks f ow s ot one]0A
0A@p.route("2F"
40login_required
ef ndex():0A 20 20q 3D visible_client_query(Client.query).filter(Client.record_type 3D=20"liente"
20 20 earch 3D equest.args.get(""2C 22".strip()
20 20 tatus 3D equest.args.get("tatus"2C 22".strip()
20 20 dvisor_project_id 3D equest.args.get("dvisor_project_id"2C ype=nt)
20 20 ommercial_plan_id 3D equest.args.get("ommercial_plan_id"2C ype=nt)
0A 20 20if earch:0A 20 20 20 20like 3D "25{earch}25"0A 20 20 20 20q 3D .filter(or_(
20 20 20 20 20 20 lient.business_name.ilike(like),0A 20 20 20 20 20 20Client.contact_name.ilike(like),0A 20 20 20 20 20 20Client.phone.ilike(like),0A 20 20 20 20 20 20Client.email.ilike(like),0A 20 20 20 20 20 20Client.code.ilike(like),0A 20 20 20 20))
0A 20 20if tatus:0A 20 20 20 20q 3D .filter_by(client_status=tatus)
20 20 lse:0A 20 20 20 20q 3D .filter(Client.client_status =20"rchivado"
0A 20 20if dvisor_project_id:0A 20 20 20 20q 3D .join(Collaborator,20Client.owner_id 3D=20Collaborator.id).filter(
20 20 20 20 20 20 ollaborator.advisor_project_id 3D=20advisor_project_id
20 20 20 20 
0A 20 20if ommercial_plan_id:0A 20 20 20 20q 3D .filter(Client.contracts.any((ClientContract.product_id 3D=20commercial_plan_id) 26 ClientContract.principal.is_(True)) 26 ClientContract.status 3D=20"ctivo"))
20 20 lients 3D .order_by(Client.updated_at.desc()).all()
20 20 dvisor_projects 3D dvisorProject.query.filter_by(active=rue).order_by(AdvisorProject.name).all()
20 20 ending_followups 3D 
20 20 f urrent_user.has_permission("rm.view":0A 20 20 20 20pending_followups 3D visible_client_query(Client.query).filter_by(record_type=22seguimiento".count()
0A 20 20return ender_template(
20 20 20 20 22clients/ndex.html"2C
20 20 20 20 lients=lients,0A 20 20 20 20search=earch,0A 20 20 20 20status=tatus,0A 20 20 20 20advisor_project_id=dvisor_project_id,0A 20 20 20 20advisor_projects=dvisor_projects,0A 20 20 20 20pending_followups=ending_followups,0A 20 20 20 20commercial_plan_id=ommercial_plan_id,0A 20 20 20 20commercial_plans=roductService.query.filter_by(category=22paquete"2C ctive=rue).order_by(ProductService.name).all(),0A 20 20)
0A
40bp.route("2Fnew"2C ethods=5B"ET"2C 22POST"5D)
40login_required
40permission_required("lients.create"
ef ew_client():0A 20 20flash(
20 20 20 20 22En mpacto exora odo egistro uevo nicia omo eguimiento. 22
20 20 20 20 22Pasar�A1  liente utom�A1ticamente uando onfirme u rimera ompra."2C
20 20 20 20 22info"2C
20 20 
20 20 eturn edirect(url_for("rm.new_prospect")
0A@p.route("2F<nt:lient_id>22)
40login_required
ef etail(client_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 f lient.record_type =20"liente"3A
20 20 20 20 eturn edirect(url_for("rm.detail"2C lient_id=lient.id))
0A 20 20collaborators 3D 5B]0A 20 20if urrent_user.has_permission("lients.assign":0A 20 20 20 20collaborators 3D 
20 20 20 20 20 20 ollaborator.query
20 20 20 20 20 20 filter_by(status=22activo"
20 20 20 20 20 20 order_by(Collaborator.job_title)
20 20 20 20 20 20 all()
20 20 20 20 
0A 20 20products 3D 5B]0A 20 20if urrent_user.has_permission("lients.edit":0A 20 20 20 20products 3D 
20 20 20 20 20 20 roductService.query
20 20 20 20 20 20 filter_by(active=rue)
20 20 20 20 20 20 order_by(ProductService.name)
20 20 20 20 20 20 all()
20 20 20 20 
0A 20 20can_financial 3D 
20 20 20 20 urrent_user.has_permission("ales.view"
20 20 20 20 r urrent_user.has_permission("inance.view"
20 20 
0A 20 20attachments 3D 
20 20 20 20 ttachment.query
20 20 20 20 filter_by(entity_type=22Client"2C ntity_id=lient.id)
20 20 20 20 order_by(Attachment.created_at.desc())
20 20 20 20 all()
20 20 
20 20 omments 3D 
20 20 20 20 lientComment.query
20 20 20 20 filter_by(client_id=lient.id)
20 20 20 20 order_by(ClientComment.created_at.desc())
20 20 20 20 all()
20 20 
20 20 perational_profile 3D 
20 20 20 20 lientOperationalProfile.query
20 20 20 20 filter_by(client_id=lient.id)
20 20 20 20 first()
20 20 
20 20 latforms 3D 
20 20 20 20 lientPlatform.query
20 20 20 20 filter_by(client_id=lient.id)
20 20 20 20 order_by(ClientPlatform.label)
20 20 20 20 all()
20 20 
0A 20 20upcoming_renewals 3D orted(
20 20 20 20 5B
20 20 20 20 20 20 ow
20 20 20 20 20 20 or ow n lient.renewals
20 20 20 20 20 20 f ow.status ot n 7B"enovado"2C 22cancelado"7D
20 20 20 20 5D,0A 20 20 20 20key=ambda ow:20row.due_date r ate.max,0A 20 20)[3A8]0A
20 20 isible_projects 3D 5B]0A 20 20if urrent_user.has_permission("rojects.view":0A 20 20 20 20visible_projects 3D 5B
20 20 20 20 20 20 ow or ow n lient.projects
20 20 20 20 20 20 f project_allowed(row)
20 20 20 20 5D
0A 20 20visible_tasks 3D 5B]0A 20 20if urrent_user.has_permission("asks.view":0A 20 20 20 20visible_tasks 3D 5B
20 20 20 20 20 20 ow or ow n lient.tasks
20 20 20 20 20 20 f task_allowed(row)
20 20 20 20 5D
0A 20 20open_tasks 3D orted(
20 20 20 20 5B
20 20 20 20 20 20 ow
20 20 20 20 20 20 or ow n isible_tasks
20 20 20 20 20 20 f ow.status ot n 7B"ompletada"2C 22cancelada"7D
20 20 20 20 5D,0A 20 20 20 20key=ambda ow:20row.due_at r atetime.max,0A 20 20)[3A10]0A
20 20 pen_tickets 3D 
20 20 20 20 5B
20 20 20 20 20 20 ow
20 20 20 20 20 20 or ow n lient.tickets
20 20 20 20 20 20 f ow.status ot n 7B"esuelto"2C 22cerrado"7D
20 20 20 20 5D
20 20 20 20 f urrent_user.has_permission("upport.view"
20 20 20 20 lse 5B]0A 20 20)
0A 20 20timeline 3D build_client_timeline(
20 20 20 20 lient,0A 20 20 20 20attachments=ttachments,0A 20 20 20 20visible_projects=isible_projects,0A 20 20 20 20visible_tasks=isible_tasks,0A 20 20 20 20can_financial=an_financial,0A 20 20)
0A 20 20principal_contract 3D ctive_principal_contract(client)
20 20 otal_invested 3D um(
20 20 20 20 
20 20 20 20 20 20 ecimal(str(row.amount r ))
20 20 20 20 20 20 or ow n lient.payments
20 20 20 20 20 20 f ow.status 3D=20"onfirmado"0A 20 20 20 20),0A 20 20 20 20Decimal("",0A 20 20)
20 20 dditional_purchase_count 3D um(
20 20 20 20 
20 20 20 20 or ale n lient.sales
20 20 20 20 f ale.operation_meta
20 20 20 20 nd ale.operation_meta.operation_type 3D=20"dditional_purchase"0A 20 20)
0A 20 20return ender_template(
20 20 20 20 22clients/etail.html"2C
20 20 20 20 lient=lient,0A 20 20 20 20collaborators=ollaborators,0A 20 20 20 20products=roducts,0A 20 20 20 20timeline=imeline,0A 20 20 20 20timeline_count=en(timeline),0A 20 20 20 20attachments=ttachments,0A 20 20 20 20comments=omments,0A 20 20 20 20operational_profile=perational_profile,0A 20 20 20 20platforms=latforms,0A 20 20 20 20platform_definitions=LATFORM_DEFINITIONS,0A 20 20 20 20upcoming_renewals=pcoming_renewals,0A 20 20 20 20visible_projects=isible_projects,0A 20 20 20 20open_tasks=pen_tasks,0A 20 20 20 20open_tickets=pen_tickets,0A 20 20 20 20principal_contract=rincipal_contract,0A 20 20 20 20total_invested=otal_invested,0A 20 20 20 20additional_purchase_count=dditional_purchase_count,0A 20 20 20 20can_financial=an_financial,0A 20 20 20 20today=ate.today(),0A 20 20)
0A
40bp.route("2F<nt:lient_id>2Fedit"2C ethods=5B"ET"2C 22POST"5D)
40login_required
40permission_required("lients.edit"
ef dit(client_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 f lient.record_type =20"liente"3A
20 20 20 20 eturn edirect(url_for("rm.detail"2C lient_id=lient.id))
20 20 ollaborators 3D active_collaborators()
20 20 perational_profile 3D lientOperationalProfile.query.filter_by(
20 20 20 20 lient_id=lient.id
20 20 .first()
0A 20 20if equest.method 3D=20"OST"3A
20 20 20 20 usiness_name 3D equest.form.get("usiness_name"2C 22".strip()
20 20 20 20 ontact_name 3D equest.form.get("ontact_name"2C 22".strip()
20 20 20 20 hone 3D equest.form.get("hone"2C 22".strip()
20 20 20 20 mail 3D equest.form.get("mail"2C 22".strip().lower()
0A 20 20 20 20if ot usiness_name r ot ontact_name:0A 20 20 20 20 20 20flash("egocio  ontacto on bligatorios."2C 22danger"
20 20 20 20 20 20 eturn ender_template(
20 20 20 20 20 20 20 20 22clients/orm.html"2C
20 20 20 20 20 20 20 20 lient=lient,0A 20 20 20 20 20 20 20 20collaborators=ollaborators,0A 20 20 20 20 20 20 20 20operational_profile=perational_profile,0A 20 20 20 20 20 20 20 20mode=22edit"2C
20 20 20 20 20 20 
0A 20 20 20 20duplicate 3D find_duplicate(business_name,20phone,20email,20exclude_id=lient.id)
20 20 20 20 f uplicate:0A 20 20 20 20 20 20flash(f"xiste tro egistro arecido:20{uplicate.business_name}"2C 22warning"
20 20 20 20 20 20 eturn ender_template(
20 20 20 20 20 20 20 20 22clients/orm.html"2C
20 20 20 20 20 20 20 20 lient=lient,0A 20 20 20 20 20 20 20 20collaborators=ollaborators,0A 20 20 20 20 20 20 20 20operational_profile=perational_profile,0A 20 20 20 20 20 20 20 20mode=22edit"2C
20 20 20 20 20 20 
0A 20 20 20 20before 3D 7B
20 20 20 20 20 20 22business_name"3A lient.business_name,0A 20 20 20 20 20 20"ontact_name"3A lient.contact_name,0A 20 20 20 20 20 20"tatus"3A lient.client_status,0A 20 20 20 20 20 20"wner_id"3A lient.owner_id,0A 20 20 20 20}0A 20 20 20 20_apply_client_form(client)
20 20 20 20 perational_profile 3D apply_operational_profile_form(
20 20 20 20 20 20 lient,0A 20 20 20 20 20 20operational_profile,0A 20 20 20 20)
20 20 20 20 udit(
20 20 20 20 20 20 22editar_cliente"2C
20 20 20 20 20 20 22Client"2C
20 20 20 20 20 20 lient.id,0A 20 20 20 20 20 20before=efore,0A 20 20 20 20 20 20after=7B
20 20 20 20 20 20 20 20 22business_name"3A lient.business_name,0A 20 20 20 20 20 20 20 20"ontact_name"3A lient.contact_name,0A 20 20 20 20 20 20 20 20"tatus"3A lient.client_status,0A 20 20 20 20 20 20 20 20"wner_id"3A lient.owner_id,0A 20 20 20 20 20 20 20 20"perational_profile_updated"3A rue,0A 20 20 20 20 20 20}2C
20 20 20 20 
20 20 20 20 b.session.commit()
20 20 20 20 lash("icha ctualizada."2C 22success"
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id))
0A 20 20return ender_template(
20 20 20 20 22clients/orm.html"2C
20 20 20 20 lient=lient,0A 20 20 20 20collaborators=ollaborators,0A 20 20 20 20operational_profile=perational_profile,0A 20 20 20 20mode=22edit"2C
20 20 
0A
40bp.route("2F<nt:lient_id>2Fconvert"2C ethods=5B"OST"5D)
40login_required
40permission_required("lients.edit"
ef onvert_to_client(client_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 f lient.record_type 3D=20"liente"3A
20 20 20 20 lash("ste egistro a s n liente."2C 22info"
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id))
0A 20 20confirmed_sale 3D 
20 20 20 20 ale.query
20 20 20 20 filter_by(client_id=lient.id)
20 20 20 20 filter(Sale.status 3D=20"onfirmada"
20 20 20 20 first()
20 20 
20 20 f ot onfirmed_sale:0A 20 20 20 20flash(
20 20 20 20 20 20 22Un eguimiento asa  liente C3�icamente uando onfirma na ompra. 22
20 20 20 20 20 20 22Registra a ompra ara ontinuar."2C
20 20 20 20 20 20 22info"2C
20 20 20 20 
20 20 20 20 eturn edirect(url_for("ales.new_sale"2C lient_id=lient.id))
0A 20 20before 3D 7B"ecord_type"3A lient.record_type,20"ipeline_stage"3A lient.pipeline_stage}0A 20 20client.record_type 3D 22cliente"0A 20 20client.pipeline_stage 3D 22venta_cerrada"0A 20 20client.client_status 3D 22activo"0A 20 20client.country 3D 22USA"0A 20 20if ot lient.code:0A 20 20 20 20client.code 3D ext_code("LI"2C lient)
20 20 udit(
20 20 20 20 22convertir_registro_cliente"2C
20 20 20 20 22Client"2C
20 20 20 20 lient.id,0A 20 20 20 20before=efore,0A 20 20 20 20after=7B"ecord_type"3A lient.record_type,20"ipeline_stage"3A lient.pipeline_stage}2C
20 20 
20 20 b.session.commit()
20 20 lash("eguimiento onvertido n liente or ompra onfirmada."2C 22success"
20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id))
0A@p.route("2F<nt:lient_id>2Farchive"2C ethods=5B"OST"5D)
40login_required
40permission_required("lients.edit"
ef rchive(client_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 efore 3D lient.client_status
20 20 lient.client_status 3D 22archivado"0A 20 20audit("rchivar_cliente"2C 22Client"2C lient.id,20before=7B"tatus"3A efore}2C fter=7B"tatus"3A 22archivado"7D)
20 20 b.session.commit()
20 20 lash("liente rchivado. u istorial e onserva."2C 22success"
20 20 eturn edirect(url_for("lients.index")
0A
40bp.route("2F<nt:lient_id>2Frestore"2C ethods=5B"OST"5D)
40login_required
40permission_required("lients.edit"
ef estore(client_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 efore 3D lient.client_status
20 20 lient.client_status 3D 22activo"0A 20 20client.record_type 3D 22cliente"0A 20 20audit("estaurar_cliente"2C 22Client"2C lient.id,20before=7B"tatus"3A efore}2C fter=7B"tatus"3A 22activo"7D)
20 20 b.session.commit()
20 20 lash("liente estaurado."2C 22success"
20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id))
0A
40bp.route("2F<nt:lient_id>2Fdelete"2C ethods=5B"OST"5D)
40login_required
40roles_required("uperadmin"2C 22admin"
ef elete_client(client_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 istory 3D client_has_history(client.id)
0A 20 20if istory:0A 20 20 20 20client.client_status 3D 22archivado"0A 20 20 20 20audit(
20 20 20 20 20 20 22intento_eliminar_cliente_con_historial"2C
20 20 20 20 20 20 22Client"2C
20 20 20 20 20 20 lient.id,0A 20 20 20 20 20 20after=7B"rchived"3A rue,20"elated"3A istory}2C
20 20 20 20 
20 20 20 20 b.session.commit()
20 20 20 20 lash(
20 20 20 20 20 20 22El liente iene istorial elacionado  o uede liminarse efinitivamente. 22
20 20 20 20 20 20 22Se rchiv�B3 ara roteger entas,20pagos  razabilidad."2C
20 20 20 20 20 20 22warning"2C
20 20 20 20 
20 20 20 20 eturn edirect(url_for("lients.index")
0A 20 20snapshot 3D 7B
20 20 20 20 22business_name"3A lient.business_name,0A 20 20 20 20"ontact_name"3A lient.contact_name,0A 20 20 20 20"hone"3A lient.phone,0A 20 20 20 20"mail"3A lient.email,0A 20 20}0A 20 20client_id_value 3D lient.id
20 20 b.session.delete(client)
20 20 udit("liminar_cliente"2C 22Client"2C lient_id_value,20before=napshot,20reason=22Eliminaci�B3n efinitiva in istorial elacionado"
20 20 b.session.commit()
20 20 lash("liente liminado efinitivamente."2C 22success"
20 20 eturn edirect(url_for("lients.index")
0A
40bp.route("2F<nt:lient_id>2Fassign"2C ethods=5B"OST"5D)
40login_required
ef ssign_collaborator(client_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 ollaborator_id 3D equest.form.get("ollaborator_id"2C ype=nt)
20 20 f ollaborator_id nd ot lientCollaborator.query.filter_by(client_id=lient.id,20collaborator_id=ollaborator_id).first():0A 20 20 20 20assignment 3D lientCollaborator(
20 20 20 20 20 20 lient_id=lient.id,0A 20 20 20 20 20 20collaborator_id=ollaborator_id,0A 20 20 20 20 20 20role_in_client=equest.form.get("ole_in_client",0A 20 20 20 20 20 20primary=ool(request.form.get("rimary"),0A 20 20 20 20)
20 20 20 20 b.session.add(assignment)
20 20 20 20 udit("signar_colaborador"2C 22Client"2C lient.id,20after=7B"ollaborator_id"3A ollaborator_id}
20 20 20 20 b.session.commit()
20 20 20 20 lash("olaborador signado."2C 22success"
20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id))
0A
40bp.route("2F<nt:lient_id>2Fassign/3Cint:ssignment_id>2Fremove"2C ethods=5B"OST"5D)
40login_required
ef emove_assignment(client_id,20assignment_id):0A 20 20assignment 3D b.get_or_404(ClientCollaborator,20assignment_id)
20 20 f ssignment.client_id 3D=20client_id:0A 20 20 20 20db.session.delete(assignment)
20 20 20 20 udit("uitar_colaborador"2C 22Client"2C lient_id,20before=7B"ollaborator_id"3A ssignment.collaborator_id}
20 20 20 20 b.session.commit()
20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient_id))
0A
40bp.route("2F<nt:lient_id>2Fcontracts"2C ethods=5B"OST"5D)
40login_required
ef dd_contract(client_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 roduct_id 3D equest.form.get("roduct_id"2C ype=nt)
20 20 roduct 3D b.session.get(ProductService,20product_id) f roduct_id lse one
20 20 f ot roduct r ot roduct.active:0A 20 20 20 20flash("elecciona n roducto  aquete ctivo."2C 22danger"
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id))
20 20 f roduct.category 3D=20"aquete"3A
20 20 20 20 lash(
20 20 20 20 20 20 22Los aquetes rincipales e egistran esde ervicio rincipal 2F pgrade ara antener recio,20pagos  aldo incronizados."2C
20 20 20 20 20 20 22info"2C
20 20 20 20 
20 20 20 20 eturn edirect(url_for("ales.principal_service"2C lient_id=lient.id))
0A 20 20status 3D equest.form.get("tatus"2C 22activo"
20 20 f tatus ot n ONTRACT_STATUSES:0A 20 20 20 20status 3D 22activo"0A
20 20 tarts_on 3D date_or_none(request.form.get("tarts_on") r ate.today()
20 20 nds_on 3D date_or_none(request.form.get("nds_on")
20 20 f nds_on nd nds_on 3C tarts_on:0A 20 20 20 20flash("a echa e encimiento o uede er nterior  a ctivaci�B3n."2C 22danger"
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id))
0A 20 20agreed_price 3D decimal_or_none(request.form.get("greed_price")
20 20 f greed_price s ot one nd greed_price 3C :0A 20 20 20 20flash("l recio cordado o uede er egativo."2C 22danger"
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id))
0A 20 20status_reason 3D request.form.get("tatus_reason" r 22".strip() r one
20 20 f tatus 3D=20"nactivo"20and ot tatus_reason:0A 20 20 20 20flash("ndica l otivo uando n aquete e egistra omo nactivo."2C 22danger"
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id))
0A 20 20principal 3D ool(request.form.get("rincipal")
20 20 f rincipal:0A 20 20 20 20ClientContract.query.filter_by(client_id=lient.id,20principal=rue).update({22principal"3A alse}
0A 20 20contract 3D lientContract(
20 20 20 20 lient_id=lient.id,0A 20 20 20 20product_id=roduct.id,0A 20 20 20 20status=tatus,0A 20 20 20 20starts_on=tarts_on,0A 20 20 20 20ends_on=nds_on,0A 20 20 20 20agreed_price=greed_price,0A 20 20 20 20principal=rincipal,0A 20 20 20 20notes=request.form.get("otes" r 22".strip() r one,0A 20 20)
20 20 b.session.add(contract)
20 20 b.session.flush()
0A 20 20detail 3D lientContractDetail(
20 20 20 20 ontract_id=ontract.id,0A 20 20 20 20modality_snapshot=request.form.get("odality_snapshot" r roduct.modality r 22".strip() r one,0A 20 20 20 20maintenance_snapshot=request.form.get("aintenance_snapshot" r roduct.maintenance r 22".strip() r one,0A 20 20 20 20benefits_snapshot=request.form.get("enefits_snapshot" r roduct.components r 22".strip() r one,0A 20 20 20 20courtesies_snapshot=request.form.get("ourtesies_snapshot" r 22".strip() r one,0A 20 20 20 20status_reason=tatus_reason,0A 20 20)
20 20 b.session.add(detail)
0A 20 20if nds_on:0A 20 20 20 20db.session.add(
20 20 20 20 20 20 enewal(
20 20 20 20 20 20 20 20 lient_id=lient.id,0A 20 20 20 20 20 20 20 20contract=ontract,0A 20 20 20 20 20 20 20 20renewal_type=roduct.name,0A 20 20 20 20 20 20 20 20due_date=nds_on,0A 20 20 20 20 20 20 20 20status=22pendiente"2C
20 20 20 20 20 20 
20 20 20 20 
0A 20 20audit(
20 20 20 20 22asignar_paquete"2C
20 20 20 20 22Client"2C
20 20 20 20 lient.id,0A 20 20 20 20after=7B"roduct_id"3A roduct.id,20"ontract_id"3A ontract.id,20"tatus"3A ontract.status}2C
20 20 
20 20 b.session.commit()
20 20 lash("aquete/ervicio gregado l istorial el liente."2C 22success"
20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id,20_anchor=22servicios")
0A
40bp.route("2F<nt:lient_id>2Fcontracts/3Cint:ontract_id>2Fupdate"2C ethods=5B"OST"5D)
40login_required
ef pdate_contract(client_id,20contract_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 ontract 3D b.get_or_404(ClientContract,20contract_id)
20 20 f ontract.client_id =20client.id:0A 20 20 20 20return edirect(url_for("lients.detail"2C lient_id=lient.id))
0A 20 20status 3D equest.form.get("tatus"2C ontract.status)
20 20 f tatus ot n ONTRACT_STATUSES:0A 20 20 20 20flash("stado e aquete o �A1lido."2C 22danger"
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id,20_anchor=22servicios")
0A 20 20starts_on 3D date_or_none(request.form.get("tarts_on") r ontract.starts_on
20 20 nds_on 3D date_or_none(request.form.get("nds_on")
20 20 f nds_on nd nds_on 3C tarts_on:0A 20 20 20 20flash("a echa e encimiento o uede er nterior  a ctivaci�B3n."2C 22danger"
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id,20_anchor=22servicios")
0A 20 20agreed_price 3D decimal_or_none(request.form.get("greed_price")
20 20 f greed_price s ot one nd greed_price 3C :0A 20 20 20 20flash("l recio cordado o uede er egativo."2C 22danger"
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id,20_anchor=22servicios")
20 20 f ontract.product nd ontract.product.category 3D=20"aquete"20and ontract.product.base_price s ot one:0A 20 20 20 20agreed_price 3D ecimal(str(contract.product.base_price))
0A 20 20detail 3D ontract.v2_detail r lientContractDetail(contract_id=ontract.id)
20 20 f ot ontract.v2_detail:0A 20 20 20 20db.session.add(detail)
0A 20 20status_reason 3D request.form.get("tatus_reason" r 22".strip() r one
20 20 f tatus 3D=20"nactivo"20and ot tatus_reason:0A 20 20 20 20flash("ndica l otivo e nactivaci�B3n el aquete."2C 22danger"
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id,20_anchor=22servicios")
0A 20 20before 3D 7B"tatus"3A ontract.status,20"tarts_on"3A tr(contract.starts_on),20"nds_on"3A tr(contract.ends_on)}0A 20 20contract.status 3D tatus
20 20 ontract.starts_on 3D tarts_on
20 20 ontract.ends_on 3D nds_on
20 20 f greed_price s ot one:0A 20 20 20 20contract.agreed_price 3D greed_price
20 20 ontract.notes 3D request.form.get("otes" r 22".strip() r one
0A 20 20principal 3D ool(request.form.get("rincipal")
20 20 f rincipal:0A 20 20 20 20ClientContract.query.filter(
20 20 20 20 20 20 lientContract.client_id 3D=20client.id,0A 20 20 20 20 20 20ClientContract.id =20contract.id,0A 20 20 20 20 20 20ClientContract.principal.is_(True),0A 20 20 20 20).update({22principal"3A alse}2C ynchronize_session=alse)
20 20 ontract.principal 3D rincipal
0A 20 20detail.modality_snapshot 3D request.form.get("odality_snapshot" r 22".strip() r ontract.product.modality
20 20 etail.maintenance_snapshot 3D request.form.get("aintenance_snapshot" r 22".strip() r ontract.product.maintenance
20 20 etail.benefits_snapshot 3D request.form.get("enefits_snapshot" r 22".strip() r one
20 20 etail.courtesies_snapshot 3D request.form.get("ourtesies_snapshot" r 22".strip() r one
20 20 etail.status_reason 3D tatus_reason
0A 20 20renewal 3D enewal.query.filter_by(contract_id=ontract.id).first()
20 20 f nds_on:0A 20 20 20 20if ot enewal:0A 20 20 20 20 20 20renewal 3D enewal(
20 20 20 20 20 20 20 20 lient_id=lient.id,0A 20 20 20 20 20 20 20 20contract=ontract,0A 20 20 20 20 20 20 20 20renewal_type=ontract.product.name,0A 20 20 20 20 20 20 20 20due_date=nds_on,0A 20 20 20 20 20 20 20 20status=22pendiente"2C
20 20 20 20 20 20 
20 20 20 20 20 20 b.session.add(renewal)
20 20 20 20 lse:0A 20 20 20 20 20 20renewal.due_date 3D nds_on
20 20 20 20 20 20 enewal.renewal_type 3D ontract.product.name
20 20 20 20 20 20 f enewal.status 3D=20"ancelado"20and tatus 3D=20"ctivo"3A
20 20 20 20 20 20 20 20 enewal.status 3D 22pendiente"0A 20 20elif enewal nd tatus n 7B"nactivo"2C 22caducado"7D:0A 20 20 20 20renewal.status 3D 22cancelado"0A
20 20 udit(
20 20 20 20 22actualizar_paquete_cliente"2C
20 20 20 20 22ClientContract"2C
20 20 20 20 ontract.id,0A 20 20 20 20before=efore,0A 20 20 20 20after=7B"tatus"3A ontract.status,20"tarts_on"3A tr(contract.starts_on),20"nds_on"3A tr(contract.ends_on)}2C
20 20 
20 20 b.session.commit()
20 20 lash("aquete ctualizado."2C 22success"
20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id,20_anchor=22servicios")
0A@p.route("2F<nt:lient_id>2Fcomment"2C ethods=5B"OST"5D)
40login_required
ef dd_comment(client_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 ody 3D request.form.get("ody" r 22".strip()
20 20 f ot ody:0A 20 20 20 20flash("scribe n omentario ntes e uardar."2C 22warning"
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id,20_anchor=22historial")
0A 20 20collaborator 3D urrent_user.collaborator
20 20 epartment 3D ollaborator.department f ollaborator lse current_user.role.label f urrent_user.role lse one)
20 20 dvisor_project 3D ollaborator.advisor_project.name f ollaborator nd ollaborator.advisor_project lse one
20 20 omment 3D lientComment(
20 20 20 20 lient_id=lient.id,0A 20 20 20 20user_id=urrent_user.id,0A 20 20 20 20process_type=request.form.get("rocess_type" r 22Seguimiento".strip(),0A 20 20 20 20process_detail=request.form.get("rocess_detail" r 22".strip() r one,0A 20 20 20 20department_snapshot=epartment,0A 20 20 20 20advisor_project_snapshot=dvisor_project,0A 20 20 20 20body=ody,0A 20 20)
20 20 b.session.add(comment)
20 20 udit("omentario_cliente"2C 22Client"2C lient.id,20after=7B"rocess_type"3A omment.process_type}
20 20 b.session.commit()
20 20 lash("omentario gregado l istorial el liente."2C 22success"
20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id,20_anchor=22historial")
0A
40bp.route("2Fexport.csv"
40login_required
ef xport_csv():0A 20 20clients 3D 
20 20 20 20 visible_client_query(Client.query)
20 20 20 20 filter_by(record_type=22cliente"
20 20 20 20 order_by(Client.id)
20 20 20 20 all()
20 20 
20 20 uf 3D o.StringIO()
20 20 riter 3D sv.writer(buf)
20 20 riter.writerow([0A 20 20 20 20"ode"2C
20 20 20 20 22business_name"2C
20 20 20 20 22contact_name"2C
20 20 20 20 22phone"2C
20 20 20 20 22other_phones"2C
20 20 20 20 22email"2C
20 20 20 20 22preferred_channel"2C
20 20 20 20 22industry"2C
20 20 20 20 22services_offered"2C
20 20 20 20 22website"2C
20 20 20 20 22facebook"2C
20 20 20 20 22instagram"2C
20 20 20 20 22other_social"2C
20 20 20 20 22address"2C
20 20 20 20 22city"2C
20 20 20 20 22state"2C
20 20 20 20 22country"2C
20 20 20 20 22timezone"2C
20 20 20 20 22source"2C
20 20 20 20 22priority"2C
20 20 20 20 22main_interest"2C
20 20 20 20 22estimated_budget"2C
20 20 20 20 22client_status"2C
20 20 20 20 22advisor"2C
20 20 5D)
20 20 or lient n lients:0A 20 20 20 20writer.writerow([0A 20 20 20 20 20 20client.code,0A 20 20 20 20 20 20client.business_name,0A 20 20 20 20 20 20client.contact_name,0A 20 20 20 20 20 20client.phone,0A 20 20 20 20 20 20client.other_phones,0A 20 20 20 20 20 20client.email,0A 20 20 20 20 20 20client.preferred_channel,0A 20 20 20 20 20 20client.industry,0A 20 20 20 20 20 20client.services_offered,0A 20 20 20 20 20 20client.website,0A 20 20 20 20 20 20client.facebook,0A 20 20 20 20 20 20client.instagram,0A 20 20 20 20 20 20client.other_social,0A 20 20 20 20 20 20client.address,0A 20 20 20 20 20 20client.city,0A 20 20 20 20 20 20client.state,0A 20 20 20 20 20 20client.country,0A 20 20 20 20 20 20client.timezone,0A 20 20 20 20 20 20client.source,0A 20 20 20 20 20 20client.priority,0A 20 20 20 20 20 20client.main_interest,0A 20 20 20 20 20 20client.estimated_budget,0A 20 20 20 20 20 20client.client_status,0A 20 20 20 20 20 20client.owner.user.name f lient.owner nd lient.owner.user lse 22"2C
20 20 20 20 5D)
20 20 udit("xportar"2C 22Client"
20 20 b.session.commit()
20 20 eturn esponse(
20 20 20 20 uf.getvalue(),0A 20 20 20 20mimetype=22text/sv"2C
20 20 20 20 eaders=7B"ontent-Disposition"3A 22attachment;20filename=lientes.csv"7D,0A 20 20)
0A
40bp.route("2F<nt:lient_id>2Foperational-profile"2C ethods=5B"OST"5D)
40login_required
40permission_required("lients.edit"
ef pdate_operational_profile(client_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 apply_operational_profile_form(client)
20 20 udit("ctualizar_perfil_operativo"2C 22Client"2C lient.id)
20 20 b.session.commit()
20 20 lash("erfil perativo ctualizado."2C 22success"
20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id,20_anchor=22datos")
0A
40bp.route("2F<nt:lient_id>2Fplatforms"2C ethods=5B"OST"5D)
40login_required
ef ave_platform(client_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 latform_id 3D equest.form.get("latform_id"2C ype=nt)
0A 20 20if latform_id:0A 20 20 20 20row 3D b.get_or_404(ClientPlatform,20platform_id)
20 20 20 20 f ow.client_id =20client.id:0A 20 20 20 20 20 20flash("a lataforma o ertenece  ste liente."2C 22danger"
20 20 20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id,20_anchor=22plataformas")
20 20 20 20 f ow.platform_key.startswith("tro_":0A 20 20 20 20 20 20label 3D request.form.get("ustom_label" r ow.label).strip()[3A120]20or ow.label
20 20 20 20 lse:0A 20 20 20 20 20 20label 3D LATFORM_DEFINITIONS.get(row.platform_key,20row.label)
20 20 lse:0A 20 20 20 20platform_key 3D request.form.get("latform_key" r 22".strip()
20 20 20 20 ustom_label 3D request.form.get("ustom_label" r 22".strip()
0A 20 20 20 20if latform_key 3D=20"tro"3A
20 20 20 20 20 20 f ot ustom_label:0A 20 20 20 20 20 20 20 20flash("scribe l ombre e a lataforma dicional."2C 22danger"
20 20 20 20 20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id,20_anchor=22plataformas")
20 20 20 20 20 20 latform_key 3D "tro_{normalize_key(custom_label)[3A45]7D"0A 20 20 20 20 20 20label 3D ustom_label[3A120]0A 20 20 20 20elif latform_key n LATFORM_DEFINITIONS:0A 20 20 20 20 20 20label 3D LATFORM_DEFINITIONS[latform_key]0A 20 20 20 20else:0A 20 20 20 20 20 20flash("lataforma o �A1lida."2C 22danger"
20 20 20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id,20_anchor=22plataformas")
0A 20 20 20 20row 3D lientPlatform.query.filter_by(client_id=lient.id,20platform_key=latform_key).first()
20 20 20 20 f ot ow:0A 20 20 20 20 20 20row 3D lientPlatform(client_id=lient.id,20platform_key=latform_key,20label=abel)
20 20 20 20 20 20 b.session.add(row)
0A 20 20status 3D equest.form.get("tatus"2C 22activo"
20 20 f tatus ot n LATFORM_STATUSES:0A 20 20 20 20status 3D 22activo"0A
20 20 ow.label 3D abel
20 20 ow.url 3D clean_url(request.form.get("rl")
20 20 ow.status 3D tatus
20 20 ow.notes 3D request.form.get("otes" r 22".strip() r one
0A 20 20audit("uardar_plataforma_cliente"2C 22Client"2C lient.id,20after=7B"latform"3A ow.label,20"tatus"3A ow.status}
20 20 b.session.commit()
20 20 lash("lataforma uardada."2C 22success"
20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id,20_anchor=22plataformas")
0A@p.route("2F<nt:lient_id>2Fplatforms/3Cint:latform_id>2Fdelete"2C ethods=5B"OST"5D)
40login_required
ef elete_platform(client_id,20platform_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 ow 3D b.get_or_404(ClientPlatform,20platform_id)
20 20 f ow.client_id =20client.id:0A 20 20 20 20flash("a lataforma o ertenece  ste liente."2C 22danger"
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id,20_anchor=22plataformas")
20 20 udit("liminar_plataforma_cliente"2C 22Client"2C lient.id,20before=7B"latform"3A ow.label}
20 20 b.session.delete(row)
20 20 b.session.commit()
20 20 lash("lataforma liminada."2C 22success"
20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id,20_anchor=22plataformas")
0A
40bp.route("2Fimport"2C ethods=5B"ET"2C 22POST"5D)
40login_required
40permission_required("lients.create"
ef mport_csv():0A 20 20if equest.method 3D=20"OST"3A
20 20 20 20 ploaded 3D equest.files.get("ile"
20 20 20 20 f ot ploaded:0A 20 20 20 20 20 20flash("elecciona n SV."2C 22danger"
20 20 20 20 20 20 eturn edirect(url_for("lients.import_csv")
0A 20 20 20 20try:0A 20 20 20 20 20 20content 3D ploaded.read().decode("tf-8-sig"
20 20 20 20 xcept nicodeDecodeError:0A 20 20 20 20 20 20uploaded.stream.seek(0)
20 20 20 20 20 20 ontent 3D ploaded.read().decode("atin-1"
0A 20 20 20 20reader 3D sv.DictReader(io.StringIO(content))
20 20 20 20 f ot eader.fieldnames:0A 20 20 20 20 20 20flash("l rchivo SV o ontiene ncabezados �A1lidos."2C 22danger"
20 20 20 20 20 20 eturn edirect(url_for("lients.import_csv")
0A 20 20 20 20collaborators 3D active_collaborators()
20 20 20 20 wner_aliases 3D owner_aliases(collaborators)
0A 20 20 20 20created 3D 
20 20 20 20 pdated 3D 
20 20 20 20 ejected 3D 5B]0A
20 20 20 20 or ine_number,20original_row n numerate(reader,20start=):0A 20 20 20 20 20 20row 3D normalized_row(original_row)
0A 20 20 20 20 20 20business 3D pick(row,20"usiness_name"2C 22negocio"2C 22empresa"2C 22compania"2C 22compa�B1ia"2C 22nombre_de_la_empresa"
20 20 20 20 20 20 ontact 3D pick(row,20"ontact_name"2C 22contacto"2C 22nombre_contacto"2C 22nombre_del_contacto" r usiness
20 20 20 20 20 20 hone 3D pick(row,20"hone"2C 22telefono"2C 22contacto_ppal"2C 22contacto_principal"2C 22telefono_principal"
20 20 20 20 20 20 ther_phones 3D pick(row,20"ther_phones"2C 22telefono_secundario"2C 22numero_secundario"2C 22secundario"
20 20 20 20 20 20 mail 3D pick(row,20"mail"2C 22correo"2C 22correo_electronico".lower()
0A 20 20 20 20 20 20if ot usiness:0A 20 20 20 20 20 20 20 20rejected.append((line_number,20"alta usiness_name 2F mpresa 2F ompa�B1�ADa")
20 20 20 20 20 20 20 20 ontinue
0A 20 20 20 20 20 20advisor_name 3D pick(row,20"dvisor"2C 22asesor"2C 22responsable"2C 22owner"
20 20 20 20 20 20 wner_id 3D wner_aliases.get(_normalize_text(advisor_name)) f dvisor_name lse one
20 20 20 20 20 20 f ot urrent_user.has_permission("rm.transfer" nd urrent_user.collaborator:0A 20 20 20 20 20 20 20 20owner_id 3D urrent_user.collaborator.id
0A 20 20 20 20 20 20values 3D 7B
20 20 20 20 20 20 20 20 22business_name"3A usiness,0A 20 20 20 20 20 20 20 20"ontact_name"3A ontact,0A 20 20 20 20 20 20 20 20"hone"3A hone,0A 20 20 20 20 20 20 20 20"ther_phones"3A ther_phones,0A 20 20 20 20 20 20 20 20"mail"3A mail,0A 20 20 20 20 20 20 20 20"referred_channel"3A pick(row,20"referred_channel"2C 22canal_preferido",0A 20 20 20 20 20 20 20 20"ndustry"3A pick(row,20"ndustry"2C 22industria"2C 22rubro",0A 20 20 20 20 20 20 20 20"ervices_offered"3A pick(row,20"ervices_offered"2C 22servicios"2C 22servicios_a_exponer",0A 20 20 20 20 20 20 20 20"ebsite"3A pick(row,20"ebsite"2C 22sitio_web"2C 22web"2C 22dominio",0A 20 20 20 20 20 20 20 20"acebook"3A pick(row,20"acebook",0A 20 20 20 20 20 20 20 20"nstagram"3A pick(row,20"nstagram",0A 20 20 20 20 20 20 20 20"ther_social"3A pick(row,20"ther_social"2C 22otras_redes"2C 22otros_enlaces",0A 20 20 20 20 20 20 20 20"ddress"3A pick(row,20"ddress"2C 22direccion",0A 20 20 20 20 20 20 20 20"ity"3A pick(row,20"ity"2C 22ciudad",0A 20 20 20 20 20 20 20 20"tate"3A pick(row,20"tate"2C 22estado"2C 22provincia",0A 20 20 20 20 20 20 20 20"ountry"3A pick(row,20"ountry"2C 22pais",0A 20 20 20 20 20 20 20 20"imezone"3A pick(row,20"imezone"2C 22zona_horaria",0A 20 20 20 20 20 20 20 20"ource"3A pick(row,20"ource"2C 22fuente",0A 20 20 20 20 20 20 20 20"riority"3A pick(row,20"riority"2C 22prioridad" r 22media"2C
20 20 20 20 20 20 20 20 22main_interest"3A pick(row,20"ain_interest"2C 22interes_principal"2C 22interes",0A 20 20 20 20 20 20 20 20"stimated_budget"3A decimal_or_none(_pick(row,20"stimated_budget"2C 22presupuesto_estimado"2C 22presupuesto"),0A 20 20 20 20 20 20 20 20"otes"3A pick(row,20"otes"2C 22notas"2C 22observaciones",0A 20 20 20 20 20 20}0A
20 20 20 20 20 20 tatus 3D normalize_text(_pick(row,20"lient_status"2C 22estado_cliente"2C 22status") r 22activo"0A 20 20 20 20 20 20if tatus ot n LIENT_STATUSES:0A 20 20 20 20 20 20 20 20status 3D 22activo"0A
20 20 20 20 20 20 uplicate 3D find_duplicate(business,20phone,20email)
20 20 20 20 20 20 f uplicate:0A 20 20 20 20 20 20 20 20role 3D urrent_user.role.name f urrent_user.role lse 22"0A 20 20 20 20 20 20 20 20allowed_owner_ids 3D 7Bc.id or  n active_collaborators()}0A 20 20 20 20 20 20 20 20if ole n 7B"dvisor"2C 22supervisor"7D nd uplicate.owner_id ot n llowed_owner_ids:0A 20 20 20 20 20 20 20 20 20 20rejected.append((line_number,20"l egistro a xiste uera e u artera  o uede odificarse esde sta mportaci�B3n")
20 20 20 20 20 20 20 20 20 20 ontinue
20 20 20 20 20 20 20 20 efore 3D 7B"ecord_type"3A uplicate.record_type,20"usiness_name"3A uplicate.business_name}0A 20 20 20 20 20 20 20 20for ield,20value n alues.items():0A 20 20 20 20 20 20 20 20 20 20if alue ot n None,20"22):0A 20 20 20 20 20 20 20 20 20 20 20 20setattr(duplicate,20field,20value)
20 20 20 20 20 20 20 20 f wner_id:0A 20 20 20 20 20 20 20 20 20 20duplicate.owner_id 3D wner_id
20 20 20 20 20 20 20 20 uplicate.record_type 3D 22cliente"0A 20 20 20 20 20 20 20 20duplicate.pipeline_stage 3D 22venta_cerrada"0A 20 20 20 20 20 20 20 20duplicate.client_status 3D tatus
20 20 20 20 20 20 20 20 f ot uplicate.code:0A 20 20 20 20 20 20 20 20 20 20duplicate.code 3D ext_code("LI"2C lient)
20 20 20 20 20 20 20 20 udit(
20 20 20 20 20 20 20 20 20 20 22actualizar_cliente_importacion"2C
20 20 20 20 20 20 20 20 20 20 22Client"2C
20 20 20 20 20 20 20 20 20 20 uplicate.id,0A 20 20 20 20 20 20 20 20 20 20before=efore,0A 20 20 20 20 20 20 20 20 20 20after=7B"ecord_type"3A 22cliente"2C 22business_name"3A uplicate.business_name}2C
20 20 20 20 20 20 20 20 
20 20 20 20 20 20 20 20 pdated 2B=201
20 20 20 20 20 20 20 20 ontinue
0A 20 20 20 20 20 20client 3D lient(
20 20 20 20 20 20 20 20 ode=ext_code("LI"2C lient),0A 20 20 20 20 20 20 20 20record_type=22cliente"2C
20 20 20 20 20 20 20 20 ipeline_stage=22venta_cerrada"2C
20 20 20 20 20 20 20 20 lient_status=tatus,0A 20 20 20 20 20 20 20 20owner_id=wner_id,0A 20 20 20 20 20 20 20 20**values,0A 20 20 20 20 20 20)
20 20 20 20 20 20 b.session.add(client)
20 20 20 20 20 20 b.session.flush()
20 20 20 20 20 20 reated 2B=201
0A 20 20 20 20audit(
20 20 20 20 20 20 22importar_clientes"2C
20 20 20 20 20 20 22Client"2C
20 20 20 20 20 20 fter=7B"reated"3A reated,20"pdated"3A pdated,20"ejected"3A en(rejected)}2C
20 20 20 20 
20 20 20 20 b.session.commit()
0A 20 20 20 20flash(
20 20 20 20 20 20 "mportaci�B3n inalizada:20{reated}20creados,20{pdated}20actualizados/onvertidos  7Blen(rejected)}20rechazados."2C
20 20 20 20 20 20 22success"20if ot ejected lse 22warning"2C
20 20 20 20 
20 20 20 20 eturn ender_template(
20 20 20 20 20 20 22clients/mport.html"2C
20 20 20 20 20 20 ejected=ejected,0A 20 20 20 20 20 20created=reated,0A 20 20 20 20 20 20updated=pdated,0A 20 20 20 20)
0A 20 20return ender_template("lients/mport.html"2C ejected=one,20created=,20updated=)
0A
40bp.route("2F<nt:lient_id>2Fattachment"2C ethods=5B"OST"5D)
40login_required
ef pload_attachment(client_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 ploaded 3D equest.files.get("ile"
20 20 f ot ploaded:0A 20 20 20 20flash("elecciona n rchivo."2C 22danger"
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id) 2B 22#rchivos"
0A 20 20category 3D request.form.get("ategory" r 22otros".strip()
20 20 f ategory ot n OCUMENT_CATEGORIES:0A 20 20 20 20category 3D 22otros"0A 20 20description 3D request.form.get("escription" r 22".strip()[3A255]20or one
0A 20 20try:0A 20 20 20 20path 3D ave_upload(uploaded,20prefix="lient_{lient.id}22)
20 20 xcept alueError s xc:0A 20 20 20 20flash(str(exc),20"anger"
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id) 2B 22#rchivos"
0A 20 20attachment 3D ttachment(
20 20 20 20 ntity_type=22Client"2C
20 20 20 20 ntity_id=lient.id,0A 20 20 20 20file_name=ploaded.filename,0A 20 20 20 20file_path=ath,0A 20 20 20 20uploaded_by_id=urrent_user.id,0A 20 20)
20 20 b.session.add(attachment)
20 20 b.session.flush()
20 20 b.session.add(
20 20 20 20 lientDocumentMeta(
20 20 20 20 20 20 lient_id=lient.id,0A 20 20 20 20 20 20attachment_id=ttachment.id,0A 20 20 20 20 20 20category=ategory,0A 20 20 20 20 20 20description=escription,0A 20 20 20 20)
20 20 
20 20 udit(
20 20 20 20 22subir_archivo_cliente"2C
20 20 20 20 22Client"2C
20 20 20 20 lient.id,0A 20 20 20 20after=7B"ile"3A ploaded.filename,20"ategory"3A ategory}2C
20 20 
20 20 b.session.commit()
20 20 lash("rchivo gregado  ategorizado n a icha."2C 22success"
20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id) 2B 22#rchivos"
0A
40bp.route("2F<nt:lient_id>2Fattachments/3Cint:ttachment_id>2Fdownload"
40login_required
ef ownload_attachment(client_id,20attachment_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 f ot urrent_user.has_permission("lients.view" r ot commercial_client_allowed(client):0A 20 20 20 20abort(403)
0A 20 20attachment 3D b.get_or_404(Attachment,20attachment_id)
20 20 f ttachment.entity_type =20"lient"20or ttachment.entity_id =20client.id:0A 20 20 20 20abort(404)
0A 20 20filename 3D ath(attachment.file_path r 22".name
20 20 f ot ilename:0A 20 20 20 20abort(404)
20 20 eturn end_from_directory(
20 20 20 20 urrent_app.config[22UPLOAD_FOLDER"5D,0A 20 20 20 20filename,0A 20 20 20 20as_attachment=alse,0A 20 20 20 20download_name=ttachment.file_name,0A 20 20)
0A
40bp.route("2F<nt:lient_id>2Fattachments/3Cint:ttachment_id>2Fmeta"2C ethods=5B"OST"5D)
40login_required
ef pdate_attachment_meta(client_id,20attachment_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 ttachment 3D b.get_or_404(Attachment,20attachment_id)
20 20 f ttachment.entity_type =20"lient"20or ttachment.entity_id =20client.id:0A 20 20 20 20abort(404)
0A 20 20category 3D request.form.get("ategory" r 22otros".strip()
20 20 f ategory ot n OCUMENT_CATEGORIES:0A 20 20 20 20category 3D 22otros"0A 20 20description 3D request.form.get("escription" r 22".strip()[3A255]20or one
0A 20 20meta 3D lientDocumentMeta.query.filter_by(attachment_id=ttachment.id).first()
20 20 f ot eta:0A 20 20 20 20meta 3D lientDocumentMeta(client_id=lient.id,20attachment_id=ttachment.id)
20 20 20 20 b.session.add(meta)
20 20 eta.category 3D ategory
20 20 eta.description 3D escription
20 20 udit(
20 20 20 20 22editar_metadatos_archivo_cliente"2C
20 20 20 20 22Attachment"2C
20 20 20 20 ttachment.id,0A 20 20 20 20after=7B"ategory"3A ategory,20"escription"3A escription}2C
20 20 
20 20 b.session.commit()
20 20 lash("atos el rchivo ctualizados."2C 22success"
20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id) 2B 22#rchivos"
0A
40bp.route("2F<nt:lient_id>2Fattachments/3Cint:ttachment_id>2Fdelete"2C ethods=5B"OST"5D)
40login_required
ef elete_attachment(client_id,20attachment_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 ttachment 3D b.get_or_404(Attachment,20attachment_id)
20 20 f ttachment.entity_type =20"lient"20or ttachment.entity_id =20client.id:0A 20 20 20 20abort(404)
0A 20 20disk_path 3D ath(current_app.config[22UPLOAD_FOLDER"5D) 2F ath(attachment.file_path r 22".name
20 20 f isk_path.is_file():0A 20 20 20 20try:0A 20 20 20 20 20 20disk_path.unlink()
20 20 20 20 xcept SError:0A 20 20 20 20 20 20current_app.logger.warning("o e udo liminar l rchivo �ADsico 25s"2C isk_path)
0A 20 20audit("liminar_archivo_cliente"2C 22Attachment"2C ttachment.id,20before=7B"ile"3A ttachment.file_name}
20 20 b.session.delete(attachment)
20 20 b.session.commit()
20 20 lash("rchivo liminado e a icha."2C 22warning"
20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id) 2B 22#rchivos"
0A
ef sale_for_client_or_404(client,20sale_id):0A 20 20sale 3D b.get_or_404(Sale,20sale_id)
20 20 f ale.client_id =20client.id:0A 20 20 20 20abort(404)
20 20 eturn ale
0A
40bp.route("2F<nt:lient_id>2Finstallments"2C ethods=5B"OST"5D)
40login_required
ef dd_installment(client_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 ale_id 3D equest.form.get("ale_id"2C ype=nt)
20 20 f ot ale_id:0A 20 20 20 20flash("elecciona na enta ara egistrar a uota."2C 22danger"
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id) 2B 22#obranza"
20 20 ale 3D sale_for_client_or_404(client,20sale_id)
0A 20 20amount 3D decimal_or_none(request.form.get("mount")
20 20 ue_date 3D date_or_none(request.form.get("ue_date")
20 20 f mount s one r mount 3C=200 r ot ue_date:0A 20 20 20 20flash("a uota equiere onto ayor ue ero  echa e encimiento �A1lida."2C 22danger"
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id) 2B 22#obranza"
0A 20 20recalc_sale(sale)
20 20 cheduled_outstanding 3D um(
20 20 20 20 Decimal(str(row.amount r ))  ecimal(str(row.paid_amount r )) or ow n ale.installments),0A 20 20 20 20Decimal("",0A 20 20)
20 20 emaining_to_schedule 3D ax(Decimal("",20Decimal(str(sale.balance r ))  cheduled_outstanding)
20 20 f mount 3E emaining_to_schedule:0A 20 20 20 20flash(
20 20 20 20 20 20 "a uota xcede l aldo �BAn o rogramado e 7Bsale.currency}20{emaining_to_schedule:2C.2f}"2C
20 20 20 20 20 20 22danger"2C
20 20 20 20 
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id) 2B 22#obranza"
0A 20 20sequence 3D ax([ow.sequence r  or ow n ale.installments]20or 5B0] 2B 
20 20 aseline_paid 3D 
20 20 20 20 ecimal(str(sale.installments[]base_paid_amount r ))
20 20 20 20 f ale.installments
20 20 20 20 lse ecimal(str(sale.amount_paid r ))
20 20 
20 20 ow 3D lientInstallment(
20 20 20 20 lient_id=lient.id,0A 20 20 20 20sale_id=ale.id,0A 20 20 20 20sequence=equence,0A 20 20 20 20amount=mount,0A 20 20 20 20paid_amount=,0A 20 20 20 20base_paid_amount=aseline_paid,0A 20 20 20 20due_date=ue_date,0A 20 20 20 20status=22vencida"20if ue_date 3C ate.today() lse 22pendiente"2C
20 20 20 20 otes=request.form.get("otes" r 22".strip() r one,0A 20 20 20 20created_by_id=urrent_user.id,0A 20 20)
20 20 b.session.add(row)
20 20 b.session.flush()
20 20 ecalc_sale(sale)
20 20 udit(
20 20 20 20 22crear_cuota_cliente"2C
20 20 20 20 22ClientInstallment"2C
20 20 20 20 ow.id,0A 20 20 20 20after=7B"ale_id"3A ale.id,20"mount"3A tr(amount),20"ue_date"3A tr(due_date)}2C
20 20 
20 20 b.session.commit()
20 20 lash("uota gregada l lan e ago."2C 22success"
20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id) 2B 22#obranza"
0A
40bp.route("2F<nt:lient_id>2Finstallments/3Cint:nstallment_id>2Fdelete"2C ethods=5B"OST"5D)
40login_required
ef elete_installment(client_id,20installment_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 ow 3D b.get_or_404(ClientInstallment,20installment_id)
20 20 f ow.client_id =20client.id:0A 20 20 20 20abort(404)
20 20 f ecimal(str(row.paid_amount r )) 3E :0A 20 20 20 20flash("o e uede liminar na uota ue a iene agos plicados."2C 22danger"
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id) 2B 22#obranza"
0A 20 20sale 3D ow.sale
20 20 udit("liminar_cuota_cliente"2C 22ClientInstallment"2C ow.id,20before=7B"mount"3A tr(row.amount)}
20 20 b.session.delete(row)
20 20 b.session.flush()
20 20 ecalc_sale(sale)
20 20 b.session.commit()
20 20 lash("uota liminada el lan e ago."2C 22warning"
20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id) 2B 22#obranza"
0A
40bp.route("2F<nt:lient_id>2Fcollection-notes"2C ethods=5B"OST"5D)
40login_required
ef dd_collection_note(client_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 ote_type 3D request.form.get("ote_type" r 22cobranza".strip()
20 20 f ote_type ot n OLLECTION_NOTE_TYPES:0A 20 20 20 20note_type 3D 22cobranza"0A 20 20body 3D request.form.get("ody" r 22".strip()
20 20 f ot ody:0A 20 20 20 20flash("a ota e obranza o uede star ac�ADa."2C 22danger"
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id) 2B 22#obranza"
0A 20 20sale_id 3D equest.form.get("ale_id"2C ype=nt)
20 20 ale 3D sale_for_client_or_404(client,20sale_id) f ale_id lse one
20 20 romised_amount 3D decimal_or_none(request.form.get("romised_amount")
20 20 romise_date 3D date_or_none(request.form.get("romise_date")
0A 20 20if romised_amount s ot one nd romised_amount 3C :0A 20 20 20 20flash("l onto rometido o uede er egativo."2C 22danger"
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id) 2B 22#obranza"
20 20 f ote_type 3D=20"romesa"20and not ale r ot romise_date r romised_amount s one r romised_amount 3C=200):0A 20 20 20 20flash("na romesa equiere enta,20monto rometido  echa e ompromiso."2C 22danger"
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id) 2B 22#obranza"
20 20 f ale nd romised_amount s ot one nd romised_amount 3E ecimal(str(sale.balance r )):0A 20 20 20 20flash("l onto rometido o uede uperar l aldo e a enta."2C 22danger"
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id) 2B 22#obranza"
0A 20 20receivable 3D ale.receivable f ale lse one
20 20 ow 3D lientCollectionNote(
20 20 20 20 lient_id=lient.id,0A 20 20 20 20sale_id=ale.id f ale lse one,0A 20 20 20 20receivable_id=eceivable.id f eceivable lse one,0A 20 20 20 20note_type=ote_type,0A 20 20 20 20promised_amount=romised_amount,0A 20 20 20 20promise_date=romise_date,0A 20 20 20 20status=22abierta"2C
20 20 20 20 ody=ody,0A 20 20 20 20created_by_id=urrent_user.id,0A 20 20)
20 20 b.session.add(row)
20 20 f ote_type 3D=20"romesa"20and eceivable:0A 20 20 20 20receivable.promise_date 3D romise_date
20 20 20 20 eceivable.status 3D 22promesa_pago"0A 20 20if ale:0A 20 20 20 20recalc_sale(sale)
20 20 b.session.flush()
20 20 udit(
20 20 20 20 22nota_cobranza_cliente"2C
20 20 20 20 22ClientCollectionNote"2C
20 20 20 20 ow.id,0A 20 20 20 20after=7B"ype"3A ote_type,20"ale_id"3A ale.id f ale lse one,20"romise_date"3A tr(promise_date) f romise_date lse one}2C
20 20 
20 20 b.session.commit()
20 20 lash("eguimiento e obranza egistrado."2C 22success"
20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id) 2B 22#obranza"
0A
40bp.route("2F<nt:lient_id>2Fcollection-notes/3Cint:ote_id>2F<ction>22,20methods=5B"OST"5D)
40login_required
ef ollection_note_action(client_id,20note_id,20action):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 ow 3D b.get_or_404(ClientCollectionNote,20note_id)
20 20 f ow.client_id =20client.id:0A 20 20 20 20abort(404)
20 20 arget 3D 7B"omplete"3A 22cumplida"2C 22miss"3A 22incumplida"2C 22cancel"3A 22cancelada"7D.get(action)
20 20 f ot arget:0A 20 20 20 20abort(404)
20 20 ow.status 3D arget
20 20 f ow.note_type 3D=20"romesa"20and ow.receivable nd ow.receivable.promise_date 3D=20row.promise_date:0A 20 20 20 20other_open 3D lientCollectionNote.query.filter(
20 20 20 20 20 20 lientCollectionNote.receivable_id 3D=20row.receivable_id,0A 20 20 20 20 20 20ClientCollectionNote.id =20row.id,0A 20 20 20 20 20 20ClientCollectionNote.note_type 3D=20"romesa"2C
20 20 20 20 20 20 lientCollectionNote.status 3D=20"bierta"2C
20 20 20 20 .order_by(ClientCollectionNote.promise_date.desc()).first()
20 20 20 20 ow.receivable.promise_date 3D ther_open.promise_date f ther_open lse one
20 20 f ow.sale:0A 20 20 20 20recalc_sale(row.sale)
20 20 udit("ctualizar_nota_cobranza"2C 22ClientCollectionNote"2C ow.id,20after=7B"tatus"3A arget}
20 20 b.session.commit()
20 20 lash("stado el eguimiento ctualizado."2C 22success"
20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id) 2B 22#obranza"
0A
40bp.route("2F<nt:lient_id>2Fstatement"
40login_required
ef tatement(client_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 f ot current_user.has_permission("ales.view" r urrent_user.has_permission("inance.view"):0A 20 20 20 20abort(403)
20 20 f ot commercial_client_allowed(client):0A 20 20 20 20abort(403)
0A 20 20sales 3D orted(client.sales,20key=ambda ow:20(row.sale_date r ate.min,20row.id),20reverse=rue)
20 20 ayments 3D orted(client.payments,20key=ambda ow:20(row.effective_date r ate.min,20row.id),20reverse=rue)
20 20 nstallments 3D orted(client.installments,20key=ambda ow:20(row.due_date r ate.max,20row.sequence r ))
20 20 otes 3D orted(client.collection_notes,20key=ambda ow:20row.created_at r atetime.min,20reverse=rue)
20 20 eturn ender_template(
20 20 20 20 22clients/tatement.html"2C
20 20 20 20 lient=lient,0A 20 20 20 20sales=ales,0A 20 20 20 20payments=ayments,0A 20 20 20 20installments=nstallments,0A 20 20 20 20collection_notes=otes,0A 20 20 20 20generated_at=atetime.now(),0A 20 20)
