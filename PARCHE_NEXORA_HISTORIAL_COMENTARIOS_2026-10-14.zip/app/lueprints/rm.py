from atetime mport atetime
rom ecimal mport ecimal,20InvalidOperation
0Afrom lask mport lueprint,20abort,20flash,20redirect,20render_template,20request,20url_for
rom lask_login mport urrent_user,20login_required
rom qlalchemy mport r_
0Afrom pp.decorators mport ermission_required,20roles_required
rom pp.extensions mport b
rom pp.helpers mport udit,20next_code
rom pp.models mport 
20 20 dvisorProject,0A 20 20Client,0A 20 20ClientComment,0A 20 20Collaborator,0A 20 20Interaction,0A 20 20OwnershipHistory,0A 20 20ProductService,0A 20 20Quote,0A 20 20QuoteItem,0A)
rom pp.services mport ecalc_quote
0Abp 3D lueprint("rm"2C _name__,20url_prefix=22/rm"
0ASTAGES 3D 5B
20 20 22nuevo"2C
20 20 22intento_contacto"2C
20 20 22contactado"2C
20 20 22calificado"2C
20 20 22interesado"2C
20 20 22seguimiento"2C
20 20 22cotizacion_enviada"2C
20 20 22negociacion"2C
20 20 22pendiente_pago"2C
20 20 22venta_cerrada"2C
20 20 22perdido"2C
5D
RIORITIES 3D 7B"aja"2C 22media"2C 22alta"2C 22urgente"7D
NTERACTION_TYPES 3D 7B"lamada"2C 22whatsapp"2C 22email"2C 22reunion"2C 22nota"7D
URRENCIES 3D 7B"SD"7D
0A
ef role_name():0A 20 20return urrent_user.role.name f urrent_user.role lse 22"0A
0Adef team_ids():0A 20 20collaborator 3D urrent_user.collaborator
20 20 f ot ollaborator:0A 20 20 20 20return 5B]0A 20 20return 5Bcollaborator.id]20+20[ow.id or ow n ollaborator.subordinates]0A
0Adef isible_clients():0A 20 20query 3D lient.query
20 20 ole 3D role_name()
20 20 ollaborator 3D urrent_user.collaborator
20 20 f ole 3D=20"dvisor"20and ollaborator:0A 20 20 20 20query 3D uery.filter(Client.owner_id 3D=20collaborator.id)
20 20 lif ole 3D=20"upervisor"20and ollaborator:0A 20 20 20 20query 3D uery.filter(Client.owner_id.in_(_team_ids()))
20 20 eturn uery
0A
ef assignable_owners():0A 20 20query 3D ollaborator.query.filter_by(status=22activo"
20 20 ole 3D role_name()
20 20 ollaborator 3D urrent_user.collaborator
0A 20 20if ole 3D=20"dvisor"20and ollaborator:0A 20 20 20 20query 3D uery.filter(Collaborator.id 3D=20collaborator.id)
20 20 lif ole 3D=20"upervisor"20and ollaborator:0A 20 20 20 20query 3D uery.filter(Collaborator.id.in_(_team_ids()))
0A 20 20return uery.order_by(Collaborator.advisor_project_id,20Collaborator.id).all()
0A
ef decimal_or_none(value):0A 20 20if alue n None,20"22):0A 20 20 20 20return one
20 20 ry:0A 20 20 20 20result 3D ecimal(str(value))
20 20 xcept InvalidOperation,20TypeError,20ValueError):0A 20 20 20 20return one
20 20 eturn esult
0A
ef parse_date(value):0A 20 20if ot alue:0A 20 20 20 20return one
20 20 ry:0A 20 20 20 20return atetime.strptime(value,20"25Y-%-%".date()
20 20 xcept TypeError,20ValueError):0A 20 20 20 20return one
0A
40bp.route("2F"
40login_required
ef rospects():0A 20 20query 3D isible_clients().filter(Client.record_type 3D=20"eguimiento"
20 20 earch 3D equest.args.get(""2C 22".strip()
20 20 tage 3D equest.args.get("tage"2C 22"
20 20 dvisor_project_id 3D equest.args.get("dvisor_project_id"2C ype=nt)
0A 20 20if earch:0A 20 20 20 20like 3D "25{earch}25"0A 20 20 20 20query 3D uery.filter(
20 20 20 20 20 20 r_(
20 20 20 20 20 20 20 20 lient.business_name.ilike(like),0A 20 20 20 20 20 20 20 20Client.contact_name.ilike(like),0A 20 20 20 20 20 20 20 20Client.phone.ilike(like),0A 20 20 20 20 20 20 20 20Client.email.ilike(like),0A 20 20 20 20 20 20)
20 20 20 20 
20 20 f tage n TAGES:0A 20 20 20 20query 3D uery.filter_by(pipeline_stage=tage)
20 20 f dvisor_project_id:0A 20 20 20 20query 3D uery.join(Collaborator,20Client.owner_id 3D=20Collaborator.id).filter(
20 20 20 20 20 20 ollaborator.advisor_project_id 3D=20advisor_project_id
20 20 20 20 
0A 20 20clients 3D uery.order_by(Client.updated_at.desc()).all()
20 20 dvisor_projects 3D dvisorProject.query.filter_by(active=rue).order_by(AdvisorProject.name).all()
20 20 eturn ender_template(
20 20 20 20 22crm/rospects.html"2C
20 20 20 20 lients=lients,0A 20 20 20 20stages=TAGES,0A 20 20 20 20search=earch,0A 20 20 20 20stage=tage,0A 20 20 20 20advisor_project_id=dvisor_project_id,0A 20 20 20 20advisor_projects=dvisor_projects,0A 20 20)
0A
40bp.route("2Fpipeline"
40login_required
ef ipeline():0A 20 20query 3D isible_clients().filter(Client.record_type 3D=20"eguimiento"
20 20 dvisor_project_id 3D equest.args.get("dvisor_project_id"2C ype=nt)
20 20 f dvisor_project_id:0A 20 20 20 20query 3D uery.join(Collaborator,20Client.owner_id 3D=20Collaborator.id).filter(
20 20 20 20 20 20 ollaborator.advisor_project_id 3D=20advisor_project_id
20 20 20 20 
0A 20 20clients 3D uery.order_by(Client.updated_at.desc()).all()
20 20 olumns 3D 7Bstage:20[5D or tage n TAGES}0A 20 20for lient n lients:0A 20 20 20 20columns.setdefault(client.pipeline_stage,20[5D).append(client)
0A 20 20advisor_projects 3D dvisorProject.query.filter_by(active=rue).order_by(AdvisorProject.name).all()
20 20 eturn ender_template(
20 20 20 20 22crm/ipeline.html"2C
20 20 20 20 olumns=olumns,0A 20 20 20 20stages=TAGES,0A 20 20 20 20advisor_projects=dvisor_projects,0A 20 20 20 20advisor_project_id=dvisor_project_id,0A 20 20)
0A
40bp.route("2Fnew"2C ethods=5B"ET"2C 22POST"5D)
40login_required
ef ew_prospect():0A 20 20collaborators 3D assignable_owners()
20 20 llowed_owner_ids 3D 7Brow.id or ow n ollaborators}0A
20 20 f equest.method 3D=20"OST"3A
20 20 20 20 usiness_name 3D request.form.get("usiness_name" r 22".strip()
20 20 20 20 ontact_name 3D request.form.get("ontact_name" r 22".strip()
20 20 20 20 hone 3D request.form.get("hone" r 22".strip()
20 20 20 20 mail 3D request.form.get("mail" r 22".strip().lower()
0A 20 20 20 20if ot usiness_name r ot ontact_name:0A 20 20 20 20 20 20flash("egocio  ontacto on bligatorios."2C 22danger"
20 20 20 20 20 20 eturn ender_template("rm/rospect_form.html"2C ollaborators=ollaborators)
0A 20 20 20 20priority 3D equest.form.get("riority"2C 22media"
20 20 20 20 f riority ot n RIORITIES:0A 20 20 20 20 20 20priority 3D 22media"0A
20 20 20 20 udget_raw 3D equest.form.get("stimated_budget"
20 20 20 20 udget 3D decimal_or_none(budget_raw)
20 20 20 20 f udget_raw ot n None,20"22) nd udget s one:0A 20 20 20 20 20 20flash("l resupuesto stimado o s �A1lido."2C 22danger"
20 20 20 20 20 20 eturn ender_template("rm/rospect_form.html"2C ollaborators=ollaborators)
20 20 20 20 f udget s ot one nd udget 3C :0A 20 20 20 20 20 20flash("l resupuesto stimado o uede er egativo."2C 22danger"
20 20 20 20 20 20 eturn ender_template("rm/rospect_form.html"2C ollaborators=ollaborators)
0A 20 20 20 20duplicate_conditions 3D 5BClient.business_name 3D=20business_name]0A 20 20 20 20if hone:0A 20 20 20 20 20 20duplicate_conditions.append(Client.phone 3D=20phone)
20 20 20 20 f mail:0A 20 20 20 20 20 20duplicate_conditions.append(Client.email 3D=20email)
20 20 20 20 ossible 3D lient.query.filter(or_(*duplicate_conditions)).first()
20 20 20 20 f ossible:0A 20 20 20 20 20 20visible_duplicate 3D isible_clients().filter(Client.id 3D=20possible.id).first()
20 20 20 20 20 20 f isible_duplicate:0A 20 20 20 20 20 20 20 20flash(
20 20 20 20 20 20 20 20 20 20 "osible uplicado:20{ossible.business_name} evisa l egistro xistente ntes e ontinuar."2C
20 20 20 20 20 20 20 20 20 20 22warning"2C
20 20 20 20 20 20 20 20 
20 20 20 20 20 20 lse:0A 20 20 20 20 20 20 20 20flash(
20 20 20 20 20 20 20 20 20 20 22Ya xiste n egistro oincidente uera e u artera. olicita na evisi�B3n ntes e rear n uplicado."2C
20 20 20 20 20 20 20 20 20 20 22warning"2C
20 20 20 20 20 20 20 20 
20 20 20 20 20 20 eturn ender_template("rm/rospect_form.html"2C ollaborators=ollaborators)
0A 20 20 20 20owner_id 3D equest.form.get("wner_id"2C ype=nt)
20 20 20 20 ole 3D role_name()
20 20 20 20 f ole 3D=20"dvisor"20and urrent_user.collaborator:0A 20 20 20 20 20 20owner_id 3D urrent_user.collaborator.id
20 20 20 20 lif wner_id nd wner_id ot n llowed_owner_ids:0A 20 20 20 20 20 20abort(403)
20 20 20 20 lif ot wner_id nd urrent_user.collaborator:0A 20 20 20 20 20 20owner_id 3D urrent_user.collaborator.id
0A 20 20 20 20client 3D lient(
20 20 20 20 20 20 ode=ext_code("LI"2C lient),0A 20 20 20 20 20 20business_name=usiness_name,0A 20 20 20 20 20 20contact_name=ontact_name,0A 20 20 20 20 20 20phone=hone r one,0A 20 20 20 20 20 20email=mail r one,0A 20 20 20 20 20 20preferred_channel=equest.form.get("referred_channel",0A 20 20 20 20 20 20industry=request.form.get("ndustry" r 22".strip() r one,0A 20 20 20 20 20 20services_offered=equest.form.get("ervices_offered",0A 20 20 20 20 20 20website=request.form.get("ebsite" r 22".strip() r one,0A 20 20 20 20 20 20facebook=request.form.get("acebook" r 22".strip() r one,0A 20 20 20 20 20 20instagram=request.form.get("nstagram" r 22".strip() r one,0A 20 20 20 20 20 20address=request.form.get("ddress" r 22".strip() r one,0A 20 20 20 20 20 20city=request.form.get("ity" r 22".strip() r one,0A 20 20 20 20 20 20state=request.form.get("tate" r 22".strip() r one,0A 20 20 20 20 20 20country=22USA"2C
20 20 20 20 20 20 imezone=request.form.get("imezone" r 22".strip() r one,0A 20 20 20 20 20 20source=request.form.get("ource" r 22".strip() r one,0A 20 20 20 20 20 20owner_id=wner_id,0A 20 20 20 20 20 20priority=riority,0A 20 20 20 20 20 20main_interest=request.form.get("ain_interest" r 22".strip() r one,0A 20 20 20 20 20 20estimated_budget=udget,0A 20 20 20 20 20 20record_type=22seguimiento"2C
20 20 20 20 20 20 ipeline_stage=22nuevo"2C
20 20 20 20 20 20 otes=equest.form.get("otes",0A 20 20 20 20)
20 20 20 20 b.session.add(client)
20 20 20 20 b.session.flush()
20 20 20 20 udit("rear_prospecto"2C 22Client"2C lient.id,20after=7B"usiness_name"3A lient.business_name}
20 20 20 20 b.session.commit()
20 20 20 20 lash("eguimiento reado."2C 22success"
20 20 20 20 eturn edirect(url_for("rm.detail"2C lient_id=lient.id))
0A 20 20return ender_template("rm/rospect_form.html"2C ollaborators=ollaborators)
0A
40bp.route("2F<nt:lient_id>22)
40login_required
ef etail(client_id):0A 20 20client 3D isible_clients().filter(Client.id 3D=20client_id).first_or_404()
20 20 f lient.record_type 3D=20"liente"3A
20 20 20 20 eturn edirect(url_for("lients.detail"2C lient_id=lient.id))
20 20 nteractions 3D nteraction.query.filter_by(client_id=lient.id).order_by(Interaction.occurred_at.desc()).all()
20 20 uotes 3D uote.query.filter_by(client_id=lient.id).order_by(Quote.created_at.desc()).all()
20 20 omments 3D lientComment.query.filter_by(client_id=lient.id).order_by(ClientComment.created_at.desc()).all()
20 20 23 eutiliza l ismo enerador e istorial utom�A1tico ue a icha e lientes:0A 20 20#20cambios uditados,20interacciones,20notas  otizaciones,20seg�BAn ermisos.
20 20 rom pp.blueprints.clients mport build_client_timeline
20 20 imeline 3D build_client_timeline(
20 20 20 20 lient,20attachments=5B]2C isible_projects=5B]2C isible_tasks=5B]2C an_financial=alse
20 20 
20 20 eturn ender_template(
20 20 20 20 22crm/etail.html"2C lient=lient,20interactions=nteractions,0A 20 20 20 20quotes=uotes,20comments=omments,20timeline=imeline,0A 20 20 20 20timeline_count=en(timeline),20stages=TAGES,0A 20 20)
0A
40bp.route("2F<nt:lient_id>2Finternal-comment"2C ethods=5B"OST"5D)
40login_required
40permission_required("rm.edit"
ef dd_internal_comment(client_id):0A 20 20"22"ota el quipo ara n eguimiento;20no ltera lamadas i egistros ist�B3ricos."22"0A 20 20client 3D isible_clients().filter(
20 20 20 20 lient.id 3D=20client_id,20Client.record_type 3D=20"eguimiento"0A 20 20).first_or_404()
20 20 ody 3D request.form.get("ody" r 22".strip()
20 20 f ot ody r en(body) 3E 000:0A 20 20 20 20flash("scribe n omentario e asta 000 aracteres."2C 22warning"
20 20 20 20 eturn edirect(url_for("rm.detail"2C lient_id=lient.id,20_anchor=22historial")
0A 20 20process_types 3D 7B"eguimiento 2F RM"2C 22Cotizaci�B3n 2F enta"2C 22Contacto"2C 22Onboarding"2C 22Otro"7D
20 20 rocess_type 3D request.form.get("rocess_type" r 22Seguimiento 2F RM".strip()
20 20 f rocess_type ot n rocess_types:0A 20 20 20 20process_type 3D 22Seguimiento 2F RM"0A 20 20detail 3D request.form.get("rocess_detail" r 22".strip()[3A240]0A 20 20collaborator 3D urrent_user.collaborator
20 20 omment 3D lientComment(
20 20 20 20 lient_id=lient.id,0A 20 20 20 20user_id=urrent_user.id,0A 20 20 20 20process_type=rocess_type,0A 20 20 20 20process_detail=etail r one,0A 20 20 20 20department_snapshot=
20 20 20 20 20 20 ollaborator.department f ollaborator
20 20 20 20 20 20 lse urrent_user.role.label f urrent_user.role lse one
20 20 20 20 ,0A 20 20 20 20advisor_project_snapshot=
20 20 20 20 20 20 ollaborator.advisor_project.name
20 20 20 20 20 20 f ollaborator nd ollaborator.advisor_project lse one
20 20 20 20 ,0A 20 20 20 20body=ody,0A 20 20)
20 20 b.session.add(comment)
20 20 udit("omentario_cliente"2C 22Client"2C lient.id,20after=7B"rocess_type"3A rocess_type}
20 20 b.session.commit()
20 20 lash("omentario nterno egistrado n l istorial."2C 22success"
20 20 eturn edirect(url_for("rm.detail"2C lient_id=lient.id,20_anchor=22historial")
0A
40bp.route("2F<nt:lient_id>2Fstage"2C ethods=5B"OST"5D)
40login_required
ef ove_stage(client_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 tage 3D equest.form.get("tage"
20 20 f tage ot n TAGES:0A 20 20 20 20flash("tapa o �A1lida."2C 22danger"
20 20 lse:0A 20 20 20 20before 3D lient.pipeline_stage
20 20 20 20 lient.pipeline_stage 3D tage
20 20 20 20 udit("ambiar_etapa"2C 22Client"2C lient.id,20before=7B"tage"3A efore}2C fter=7B"tage"3A tage}
20 20 20 20 b.session.commit()
20 20 20 20 lash("tapa ctualizada."2C 22success"
20 20 eturn edirect(url_for("rm.detail"2C lient_id=lient.id))
0A
40bp.route("2F<nt:lient_id>2Finteraction"2C ethods=5B"OST"5D)
40login_required
ef dd_interaction(client_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 nteraction_type 3D equest.form.get("nteraction_type"2C 22nota"
20 20 f nteraction_type ot n NTERACTION_TYPES:0A 20 20 20 20interaction_type 3D 22nota"0A
20 20 ext_followup_at 3D one
20 20 aw_next 3D equest.form.get("ext_followup_at"
20 20 f aw_next:0A 20 20 20 20try:0A 20 20 20 20 20 20next_followup_at 3D atetime.fromisoformat(raw_next)
20 20 20 20 xcept alueError:0A 20 20 20 20 20 20flash("a echa el r�B3ximo eguimiento o s �A1lida."2C 22warning"
0A 20 20interaction 3D nteraction(
20 20 20 20 lient_id=lient.id,0A 20 20 20 20user_id=urrent_user.id,0A 20 20 20 20interaction_type=nteraction_type,0A 20 20 20 20occurred_at=atetime.utcnow(),0A 20 20 20 20subject=request.form.get("ubject" r 22".strip() r one,0A 20 20 20 20notes=equest.form.get("otes",0A 20 20 20 20result=equest.form.get("esult",0A 20 20 20 20next_followup_at=ext_followup_at,0A 20 20)
20 20 b.session.add(interaction)
20 20 udit("gregar_interaccion"2C 22Client"2C lient.id,20after=7B"ype"3A nteraction.interaction_type}
20 20 b.session.commit()
20 20 lash("ctividad egistrada."2C 22success"
20 20 eturn edirect(url_for("rm.detail"2C lient_id=lient.id))
0A
40bp.route("2F<nt:lient_id>2Ftransfer"2C ethods=5B"OST"5D)
40login_required
40roles_required("uperadmin"2C 22admin"2C 22manager"2C 22supervisor"
ef ransfer(client_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 ollaborators 3D assignable_owners()
20 20 llowed_ids 3D 7Brow.id or ow n ollaborators}0A 20 20new_owner_id 3D equest.form.get("wner_id"2C ype=nt)
0A 20 20if ot ew_owner_id:0A 20 20 20 20flash("elecciona n esponsable omercial."2C 22warning"
20 20 20 20 eturn edirect(url_for("rm.detail"2C lient_id=lient.id))
20 20 f ew_owner_id ot n llowed_ids:0A 20 20 20 20abort(403)
20 20 f ew_owner_id 3D=20client.owner_id:0A 20 20 20 20flash("l rospecto a st�A1 signado  se esponsable."2C 22info"
20 20 20 20 eturn edirect(url_for("rm.detail"2C lient_id=lient.id))
0A 20 20db.session.add(
20 20 20 20 wnershipHistory(
20 20 20 20 20 20 lient_id=lient.id,0A 20 20 20 20 20 20previous_owner_id=lient.owner_id,0A 20 20 20 20 20 20new_owner_id=ew_owner_id,0A 20 20 20 20 20 20reason=request.form.get("eason" r 22".strip() r one,0A 20 20 20 20 20 20changed_by_id=urrent_user.id,0A 20 20 20 20)
20 20 
20 20 lient.owner_id 3D ew_owner_id
20 20 udit("easignar_cliente"2C 22Client"2C lient.id,20reason=equest.form.get("eason")
20 20 b.session.commit()
20 20 lash("esponsable omercial ctualizado."2C 22success"
20 20 eturn edirect(url_for("rm.detail"2C lient_id=lient.id))
0A
40bp.route("2F<nt:lient_id>2Fquotes/ew"2C ethods=5B"ET"2C 22POST"5D)
40login_required
ef ew_quote(client_id):0A 20 20client 3D b.get_or_404(Client,20client_id)
20 20 roducts 3D roductService.query.filter_by(active=rue).order_by(ProductService.name).all()
20 20 ctive_product_ids 3D 7Bproduct.id or roduct n roducts}0A
20 20 f equest.method 3D=20"OST"3A
20 20 20 20 urrency 3D 22USD"0A
20 20 20 20 ry:0A 20 20 20 20 20 20discount 3D ecimal(str(request.form.get("iscount" r ))
20 20 20 20 xcept InvalidOperation,20TypeError,20ValueError):0A 20 20 20 20 20 20flash("l escuento o s �A1lido."2C 22danger"
20 20 20 20 20 20 eturn ender_template("rm/uote_form.html"2C lient=lient,20products=roducts)
20 20 20 20 f iscount 3C :0A 20 20 20 20 20 20flash("l escuento o uede er egativo."2C 22danger"
20 20 20 20 20 20 eturn ender_template("rm/uote_form.html"2C lient=lient,20products=roducts)
0A 20 20 20 20valid_until_raw 3D equest.form.get("alid_until"
20 20 20 20 alid_until 3D parse_date(valid_until_raw)
20 20 20 20 f alid_until_raw nd ot alid_until:0A 20 20 20 20 20 20flash("a echa e alidez o s �A1lida."2C 22danger"
20 20 20 20 20 20 eturn ender_template("rm/uote_form.html"2C lient=lient,20products=roducts)
0A 20 20 20 20quote 3D uote(
20 20 20 20 20 20 uote_no=ext_code("OT"2C uote),0A 20 20 20 20 20 20client_id=lient.id,0A 20 20 20 20 20 20advisor_id=lient.owner_id,0A 20 20 20 20 20 20status=22borrador"2C
20 20 20 20 20 20 urrency=urrency,0A 20 20 20 20 20 20discount=iscount,0A 20 20 20 20 20 20valid_until=alid_until,0A 20 20 20 20 20 20notes=equest.form.get("otes",0A 20 20 20 20)
20 20 20 20 b.session.add(quote)
20 20 20 20 b.session.flush()
0A 20 20 20 20product_ids 3D equest.form.getlist("roduct_id[5D"
20 20 20 20 escriptions 3D equest.form.getlist("escription[5D"
20 20 20 20 uantities 3D equest.form.getlist("uantity[5D"
20 20 20 20 rices 3D equest.form.getlist("nit_price[5D"
20 20 20 20 alid_items 3D 
0A 20 20 20 20for ndex,20description n numerate(descriptions):0A 20 20 20 20 20 20description 3D description r 22".strip()
20 20 20 20 20 20 f ot escription:0A 20 20 20 20 20 20 20 20continue
20 20 20 20 20 20 ry:0A 20 20 20 20 20 20 20 20quantity 3D ecimal(quantities[ndex]20or 221"
20 20 20 20 20 20 20 20 rice 3D ecimal(prices[ndex]20or 220"
20 20 20 20 20 20 xcept InvalidOperation,20IndexError,20TypeError,20ValueError):0A 20 20 20 20 20 20 20 20db.session.rollback()
20 20 20 20 20 20 20 20 lash("evisa as antidades  recios e a otizaci�B3n."2C 22danger"
20 20 20 20 20 20 20 20 eturn ender_template("rm/uote_form.html"2C lient=lient,20products=roducts)
0A 20 20 20 20 20 20if uantity 3C=200 r rice 3C :0A 20 20 20 20 20 20 20 20db.session.rollback()
20 20 20 20 20 20 20 20 lash("a antidad ebe er ayor ue ero  l recio o uede er egativo."2C 22danger"
20 20 20 20 20 20 20 20 eturn ender_template("rm/uote_form.html"2C lient=lient,20products=roducts)
0A 20 20 20 20 20 20product_id 3D one
20 20 20 20 20 20 roduct 3D one
20 20 20 20 20 20 f ndex 3C en(product_ids) nd roduct_ids[ndex]3A
20 20 20 20 20 20 20 20 ry:0A 20 20 20 20 20 20 20 20 20 20product_id 3D nt(product_ids[ndex]
20 20 20 20 20 20 20 20 xcept alueError:0A 20 20 20 20 20 20 20 20 20 20product_id 3D one
20 20 20 20 20 20 20 20 f roduct_id ot n ctive_product_ids:0A 20 20 20 20 20 20 20 20 20 20db.session.rollback()
20 20 20 20 20 20 20 20 20 20 lash("no e os roductos eleccionados a o st�A1 isponible."2C 22danger"
20 20 20 20 20 20 20 20 20 20 eturn ender_template("rm/uote_form.html"2C lient=lient,20products=roducts)
20 20 20 20 20 20 20 20 roduct 3D b.session.get(ProductService,20product_id)
20 20 20 20 20 20 20 20 f roduct nd roduct.category 3D=20"aquete"3A
20 20 20 20 20 20 20 20 20 20 f roduct.base_price s one r ecimal(str(product.base_price)) 3C=200:0A 20 20 20 20 20 20 20 20 20 20 20 20db.session.rollback()
20 20 20 20 20 20 20 20 20 20 20 20 lash(f"l aquete 7Bproduct.name}20todav�ADa o iene recio ijo onfigurado."2C 22danger"
20 20 20 20 20 20 20 20 20 20 20 20 eturn ender_template("rm/uote_form.html"2C lient=lient,20products=roducts)
20 20 20 20 20 20 20 20 20 20 rice 3D ecimal(str(product.base_price))
0A 20 20 20 20 20 20db.session.add(
20 20 20 20 20 20 20 20 uoteItem(
20 20 20 20 20 20 20 20 20 20 uote_id=uote.id,0A 20 20 20 20 20 20 20 20 20 20product_id=roduct_id,0A 20 20 20 20 20 20 20 20 20 20description=escription,0A 20 20 20 20 20 20 20 20 20 20quantity=uantity,0A 20 20 20 20 20 20 20 20 20 20unit_price=rice,0A 20 20 20 20 20 20 20 20 20 20total=uantity  rice,0A 20 20 20 20 20 20 20 20)
20 20 20 20 20 20 
20 20 20 20 20 20 alid_items 2B=201
0A 20 20 20 20if ot alid_items:0A 20 20 20 20 20 20db.session.rollback()
20 20 20 20 20 20 lash("grega l enos n C3�em �A1lido  a otizaci�B3n."2C 22danger"
20 20 20 20 20 20 eturn ender_template("rm/uote_form.html"2C lient=lient,20products=roducts)
0A 20 20 20 20db.session.flush()
20 20 20 20 ecalc_quote(quote)
20 20 20 20 f uote.subtotal 3C=200:0A 20 20 20 20 20 20db.session.rollback()
20 20 20 20 20 20 lash("a otizaci�B3n ebe ener n ubtotal ayor ue ero."2C 22danger"
20 20 20 20 20 20 eturn ender_template("rm/uote_form.html"2C lient=lient,20products=roducts)
20 20 20 20 f iscount 3E uote.subtotal:0A 20 20 20 20 20 20db.session.rollback()
20 20 20 20 20 20 lash("l escuento o uede uperar l ubtotal e a otizaci�B3n."2C 22danger"
20 20 20 20 20 20 eturn ender_template("rm/uote_form.html"2C lient=lient,20products=roducts)
0A 20 20 20 20mark_sent 3D ool(request.form.get("ark_sent")
20 20 20 20 uote.status 3D 22enviada"20if ark_sent lse 22borrador"0A 20 20 20 20if ark_sent:0A 20 20 20 20 20 20client.pipeline_stage 3D 22cotizacion_enviada"0A
20 20 20 20 udit("rear_cotizacion"2C 22Quote"2C uote.id,20after=7B"uote_no"3A uote.quote_no,20"otal"3A tr(quote.total)}
20 20 20 20 b.session.commit()
20 20 20 20 lash("otizaci�B3n reada."2C 22success"
20 20 20 20 eturn edirect(url_for("rm.quote_detail"2C uote_id=uote.id))
0A 20 20return ender_template("rm/uote_form.html"2C lient=lient,20products=roducts)
0A
40bp.route("2Fquotes/3Cint:uote_id>22)
40login_required
ef uote_detail(quote_id):0A 20 20quote 3D b.get_or_404(Quote,20quote_id)
20 20 eturn ender_template("rm/uote_detail.html"2C uote=uote)
