from atetime mport ate
rom athlib mport ath
mport ytest
0Afrom pp mport reate_app
rom pp.extensions mport b
rom pp.models mport lient,20ClientComment,20Role,20User
rom cripts.seed mport eed_all
0A
lass onfig:0A 20 20TESTING 3D rue
20 20 ECRET_KEY 3D 22test-quick-history"0A 20 20SQLALCHEMY_DATABASE_URI 3D 22sqlite:2F/2F:emory:22
20 20 QLALCHEMY_TRACK_MODIFICATIONS 3D alse
20 20 TF_CSRF_ENABLED 3D alse
20 20 PLOAD_FOLDER 3D tr(Path(__file__).parent 2F 22uploads_quick_history"
20 20 AX_CONTENT_LENGTH 3D 0  024  024
20 20 OMPANY_NAME 3D 22Impacto edia gency"0A 20 20COMPANY_TIMEZONE 3D 22America/anagua"0A 20 20SMTP_HOST 3D one
20 20 MTP_PORT 3D 87
20 20 MTP_USER 3D one
20 20 MTP_PASSWORD 3D one
20 20 MTP_FROM 3D 22test@xample.com"0A 20 20SMTP_USE_TLS 3D alse
0A
40pytest.fixture()
ef pp():0A 20 20app 3D reate_app(Config)
20 20 ith pp.app_context():0A 20 20 20 20db.create_all()
20 20 20 20 eed_all()
20 20 20 20 dmin 3D ser(
20 20 20 20 20 20 ame=22Admin istorial"2C
20 20 20 20 20 20 mail=22history-admin@est.local"2C
20 20 20 20 20 20 ole=ole.query.filter_by(name=22admin".one(),0A 20 20 20 20 20 20active=rue,0A 20 20 20 20)
20 20 20 20 dmin.set_password("istoryTest123!"
20 20 20 20 b.session.add(admin)
20 20 20 20 b.session.flush()
20 20 20 20 b.session.add_all([0A 20 20 20 20 20 20Client(
20 20 20 20 20 20 20 20 ode=22QH-CLIENT"2C usiness_name=22Cliente istorial"2C
20 20 20 20 20 20 20 20 ontact_name=22Contacto"2C ecord_type=22cliente"2C
20 20 20 20 20 20 20 20 ipeline_stage=22venta_cerrada"2C lient_status=22activo"2C
20 20 20 20 20 20 ,0A 20 20 20 20 20 20Client(
20 20 20 20 20 20 20 20 ode=22QH-LEAD"2C usiness_name=22Seguimiento istorial"2C
20 20 20 20 20 20 20 20 ontact_name=22Contacto"2C ecord_type=22seguimiento"2C
20 20 20 20 20 20 20 20 ipeline_stage=22contactado"2C lient_status=22activo"2C
20 20 20 20 20 20 ,0A 20 20 20 20]
20 20 20 20 b.session.commit()
20 20 ield pp
0A
40pytest.fixture()
ef rowser(app):0A 20 20client 3D pp.test_client()
20 20 esponse 3D lient.post("2Fauth/ogin"2C ata=7B
20 20 20 20 22email"3A 22history-admin@est.local"2C
20 20 20 20 22password"3A 22HistoryTest123!"2C
20 20 7D)
20 20 ssert esponse.status_code 3D=20302
20 20 eturn lient
0A
ef est_client_history_is_easy_to_open(browser,20app):0A 20 20with pp.app_context():0A 20 20 20 20row 3D lient.query.filter_by(code=22QH-CLIENT".one()
20 20 20 20 id 3D ow.id
20 20 esponse 3D rowser.get(f"2Fclients/7Bcid}22)
20 20 ssert esponse.status_code 3D=20200
20 20 tml 3D esponse.get_data(as_text=rue)
20 20 ssert data-client-history-open' n tml
20 20 ssert id=22clientHistoryTab" n tml
20 20 ssert id=22historial" n tml
20 20 ssert Timeline utom�A1tico' n tml
0A
ef est_client_comment_keeps_history_open(browser,20app):0A 20 20with pp.app_context():0A 20 20 20 20cid 3D lient.query.filter_by(code=22QH-CLIENT".one().id
20 20 esult 3D rowser.post(f"2Fclients/7Bcid}2Fcomment"2C ata=7B
20 20 20 20 22process_type"3A 22Seguimiento 2F RM"2C
20 20 20 20 22body"3A 22Nota ara l quipo omercial"2C
20 20 7D)
20 20 ssert esult.status_code 3D=20302
20 20 ssert esult.headers[22Location"5D.endswith("23historial"
0A
ef est_crm_history_includes_internal_comments(browser,20app):0A 20 20with pp.app_context():0A 20 20 20 20cid 3D lient.query.filter_by(code=22QH-LEAD".one().id
20 20 esponse 3D rowser.get(f"2Fcrm/7Bcid}22)
20 20 ssert esponse.status_code 3D=20200
20 20 ssert 22Historial  omentarios"20in esponse.get_data(as_text=rue)
0A 20 20result 3D rowser.post(f"2Fcrm/7Bcid}2Finternal-comment"2C ata=7B
20 20 20 20 22process_type"3A 22Seguimiento 2F RM"2C
20 20 20 20 22body"3A 22Nota nterna obre a ropuesta"2C
20 20 7D)
20 20 ssert esult.status_code 3D=20302
20 20 ssert esult.headers[22Location"5D.endswith("23historial"
20 20 ith pp.app_context():0A 20 20 20 20assert lientComment.query.filter_by(client_id=id).count() 3D=201
0A 20 20page 3D rowser.get(f"2Fcrm/7Bcid}22)
20 20 ssert age.status_code 3D=20200
20 20 ssert 22Nota nterna obre a ropuesta"20in age.get_data(as_text=rue)
0A
ef est_crm_empty_comment_is_rejected(browser,20app):0A 20 20with pp.app_context():0A 20 20 20 20cid 3D lient.query.filter_by(code=22QH-LEAD".one().id
20 20 esponse 3D rowser.post(f"2Fcrm/7Bcid}2Finternal-comment"2C ata=7B"ody"3A 22 22}
20 20 ssert esponse.status_code 3D=20302
20 20 ith pp.app_context():0A 20 20 20 20assert lientComment.query.filter_by(client_id=id).count() 3D=200
0A
ef est_crm_stage_changes_appear_in_automatic_timeline(browser,20app):0A 20 20with pp.app_context():0A 20 20 20 20cid 3D lient.query.filter_by(code=22QH-LEAD".one().id
20 20 hanged 3D rowser.post(f"2Fcrm/7Bcid}2Fstage"2C ata=7B"tage"3A 22interesado"7D)
20 20 ssert hanged.status_code 3D=20302
20 20 age 3D rowser.get(f"2Fcrm/7Bcid}22)
20 20 ssert age.status_code 3D=20200
20 20 tml 3D age.get_data(as_text=rue)
20 20 ssert 22Cambio e tapa"20in tml
20 20 ssert 22Contactado"20in tml
20 20 ssert 22Interesado"20in tml
